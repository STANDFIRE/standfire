package capsis.lib.forenerchips.workingprocess;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.lib.forenerchips.Resource;
import capsis.lib.forenerchips.ResourceSite;
import capsis.lib.forenerchips.ResourceStatus;
import capsis.lib.forenerchips.MaterialMarketDestination;
import capsis.lib.forenerchips.WorkingProcess;

/**
 * A harvesting working process
 * 
 * @author N. Bilot - February 2013
 */
public class HarvestingProcessBis extends WorkingProcess {

  private String name;
	private double movingSpeed; // km/h
	private double acquirePerf; // mn/cm
	private double cuttingPerf; // mn/cm
	private double buckingPerf; // t/h
  private String stemMarketDestination; // "ND", "ENERGY", "INDUSTRY", or "LUMBER
  private String branchesMarketDestination; // "ND", "ENERGY", "INDUSTRY", or "LUMBER
  private double enginePower; // kW
  private double workLoad_moving; // ratio
  private double workLoad_acquiring; // ratio
  private double workLoad_cutting; // ratio
  private double workLoad_bucking; // ratio
  private double machineWheight; // t
  private double machineLifetime; // h
  private double machineToHumanTimeRatio; // e.g. 1.5
	private double QGPlotDistance; // km

	/**
	 * Constructor (Abatteuse faconeuse ou bucheron à pied). Choices in parameter inspired by Lortz
	 * (1991): Manual felling time and productivity in southern pine forests
	 */
	public HarvestingProcessBis (String name, double movingSpeed, double acquirePerf, double cuttingPerf, double buckingPerf, String stemMarketDestination, String branchsMarketDestination, double enginePower, double workLoad_moving, double workLoad_acquiring, double workLoad_cutting, double workLoad_bucking, double machineWheight, double machineLifetime, double machineToHumanTimeRatio, double QGPlotDistance) throws Exception {
		super ("HarvestingProcessBis");

    
		// Check throws an exception if the condition is false
		check ("movingSpeed", movingSpeed >= 0);
		check ("acquirePerf", acquirePerf >= 0);
		check ("cuttingPerf", cuttingPerf >= 0);
		check ("buckingPerf", buckingPerf >= 0);
    check ("stemMarketDestination", stemMarketDestination.equals (MaterialMarketDestination.ND) || stemMarketDestination.equals (MaterialMarketDestination.ENERGY) || stemMarketDestination.equals (MaterialMarketDestination.INDUSTRY) || stemMarketDestination.equals (MaterialMarketDestination.LUMBER));
    check ("branchesMarketDestination", branchesMarketDestination.equals (MaterialMarketDestination.ND) || branchesMarketDestination.equals (MaterialMarketDestination.ENERGY) || branchesMarketDestination.equals (MaterialMarketDestination.INDUSTRY) || branchesMarketDestination.equals (MaterialMarketDestination.LUMBER));
    
		check ("enginePower", enginePower >= 0);
    check ("workLoad_moving", workLoad_moving >= 0);
    check ("workLoad_moving", workLoad_moving <= 1);
    check ("workLoad_acquiring", workLoad_acquiring >= 0);
    check ("workLoad_acquiring", workLoad_acquiring <= 1);
    check ("workLoad_cutting", workLoad_cutting >= 0);
    check ("workLoad_cutting", workLoad_cutting <= 1);
    check ("workLoad_bucking", workLoad_bucking >= 0);
    check ("workLoad_bucking", workLoad_bucking <= 1);
    check ("machineWheight", machineWheight >= 0);
    check ("machineLifetime", machineLifetime >= 0);
		check ("machineToHumanTimeRatio", machineToHumanTimeRatio >= 0);
		check ("QGPlotDistance", QGPlotDistance >= 0);

		this.name = name;
		this.movingSpeed = movingSpeed;
		this.acquirePerf = acquirePerf;
		this.cuttingPerf = cuttingPerf;
		this.buckingPerf = buckingPerf;
    this.stemMarketDestination = stemMarketDestination;
    this.branchesMarketDestination = branchesMarketDestination;
		this.enginePower = enginePower;
    this.workLoad_moving = workLoad_moving;
    this.workLoad_acquiring = workLoad_acquiring;
    this.workLoad_cutting = workLoad_cutting;
    this.workLoad_bucking = workLoad_bucking;
    this.machineWheight = machineWheight;
    this.machineLifetime = machineLifetime;
		this.machineToHumanTimeRatio = machineToHumanTimeRatio;
		this.QGPlotDistance = QGPlotDistance;

		// What resource can be processed
		addCompatibleStatusOrSite (ResourceStatus.STANDING_TREE);
		addCompatibleStatusOrSite (ResourceSite.PLOT);

	}

	/**
	 * Creates an instance with all parameters in a single String, for scenarios in txt files.
	 */
	static public HarvestingProcessBis getInstance (String name, String parameters) throws Exception {
		StringTokenizer st = new StringTokenizer (parameters, " ");
		
    String wpName = name;
		double movingSpeed = doubleValue (st.nextToken ());
		double acquirePerf = doubleValue (st.nextToken ());
		double cuttingPerf = doubleValue (st.nextToken ());
		double buckingPerf = doubleValue (st.nextToken ());
   double enginePower = doubleValue (st.nextToken ());
    double workLoad_moving = doubleValue (st.nextToken ());
    double workLoad_acquiring = doubleValue (st.nextToken ());
    double workLoad_cutting = doubleValue (st.nextToken ());
    double workLoad_bucking = doubleValue (st.nextToken ());
    double machineWheight = doubleValue (st.nextToken ());
    double machineLifetime = doubleValue (st.nextToken ());
		double machineToHumanTimeRatio = doubleValue (st.nextToken ());
		double QGPlotDistance = doubleValue (st.nextToken ());
    
    String stemMarketDestination = st.nextToken ();
    if (stemMarketDestination.equals ("LUMBER")) 
			stemMarketDestination = MaterialMarketDestination.LUMBER;
		else if (stemMarketDestination.equals ("INDUSTRY")) 
			stemMarketDestination = MaterialMarketDestination.INDUSTRY;
    else if (stemMarketDestination.equals ("ENERGY")) 
			stemMarketDestination = MaterialMarketDestination.ENERGY;
    else if (stemMarketDestination.equals ("ND")) 
			stemMarketDestination = MaterialMarketDestination.ND;
		else 
			throw new Exception ("MaterialMarketDestination: wrong value for stemMarketDestination: "+stemMarketDestination+", must be LUMBER, INDUSTRY, ENERGY or ND");
    
    String branchesMarketDestination = st.nextToken ();
    if (branchesMarketDestination.equals ("LUMBER")) 
			branchesMarketDestination = MaterialMarketDestination.LUMBER;
		else if (branchesMarketDestination.equals ("INDUSTRY")) 
			branchesMarketDestination = MaterialMarketDestination.INDUSTRY;
    else if (branchesMarketDestination.equals ("ENERGY")) 
			branchesMarketDestination = MaterialMarketDestination.ENERGY;
    else if (branchesMarketDestination.equals ("ND")) 
			branchesMarketDestination = MaterialMarketDestination.ND;
    else 
			throw new Exception ("MaterialMarketDestination: wrong value for branchesMarketDestination: "+branchesMarketDestination+", must be LUMBER, INDUSTRY, ENERGY or ND");
		
		return new HarvestingProcessBis (name, movingSpeed,  acquirePerf,  cuttingPerf,  buckingPerf, stemMarketDestination, branchesMarketDestination, 
				 enginePower, workLoad_moving, workLoad_acquiring, workLoad_cutting, workLoad_bucking, machineWheight, machineLifetime, machineToHumanTimeRatio,  QGPlotDistance);
	}

	/**
	 * Run the harvesting process
	 */
	@Override
	public void run () throws Exception {
		checkInputCompatibility ();

		// Efficiency
		double efficiency = 1;

		// Consumptions
		// 1. fuelConsumption
      double engineEfficiency = 0.35;
    
      double movingTime_h = input.treeNumber * (Math.sqrt (input.plotArea_ha * 10000) / Math.sqrt (input.treeNumber))
          / (movingSpeed * 1000);
      double hourlyConsumption_moving = enginePower * workLoad_moving / engineEfficiency;
      double fuelConsumption_moving = hourlyConsumption_moving * movingTime_h;
     
      double acquireTime_h = input.treeNumber * acquirePerf * Math.pow (input.Dg / 2.54, 0.2) / 60d;
      double hourlyConsumption_acquiring = enginePower * workLoad_acquiring / engineEfficiency;
      double fuelConsumption_acquiring = hourlyConsumption_acquiring * acquireTime_h;
      
      double cuttingTime_h = input.treeNumber * cuttingPerf * Math.pow (input.Dg / 2.54, 0.937) / 60d;
      double hourlyConsumption_cutting = enginePower * workLoad_cutting / engineEfficiency;
      double fuelConsumption_cutting = hourlyConsumption_cutting * cuttingTime_h;
      
      double buckingTime_h = input.treeNumber * input.wetBiomass / buckingPerf;
      double hourlyConsumption_bucking = enginePower * workLoad_bucking / engineEfficiency;
      double fuelConsumption_bucking = hourlyConsumption_bucking * buckingTime_h;
      
      double harvestingTime_h = acquireTime_h + cuttingTime_h + buckingTime_h;
      double fuelConsumption = fuelConsumption_moving + fuelConsumption_acquiring + fuelConsumption_cutting + fuelConsumption_bucking;
      
    // 2. Oil consumption
      double oilCoefficient = 0.058;
      double oilConsumption = fuelConsumption * oilCoefficient;

    // 3. Life Cycle consumption equivalent
      double lcConsumption_pert = 16556;
      double totalMachineTime_h = (movingTime_h + acquireTime_h + cuttingTime_h + buckingTime_h);
      double lcConsumption_perh = machineWheight * lcConsumption_pert / machineLifetime;
      double lcConsumption = lcConsumption_perh * totalMachineTime_h;
      

    // 4. Logistics consumption
      // a. operatorTravelConsumption
      double humanProductiveWorkTime = totalMachineTime_h * machineToHumanTimeRatio;
      int humanProductiveWorkTime_day = (int) Math.ceil (humanProductiveWorkTime / WORKING_DAY_DURATION);
      double operatorTravelConsumption = QGPlotDistance * 2d * MEAN_CAR_CONSUMPTION * humanProductiveWorkTime_day; // kWh

      //  b. machineTravelConsumption
      double machineTravelConsumption = QGPlotDistance * 2d * MEAN_CARRIER_CONSUMPTION; // kWh

    double logisticsConsumption = operatorTravelConsumption + machineTravelConsumption;

      
    // PROCESS CONSUMPTION
    double processConsumption = fuelConsumption + oilConsumption + lcConsumption + logisticsConsumption;

		// Transformation
		// => the process outputs only LOG or RESIDUALS, it doesn't exist on any other resource than softwood (resineux), and branches are always considered as residuals for this resource.
  
    if(stemMarketDestination.equals (MaterialMarketDestination.LUMBER)){
    
      // The Bole is destined to LUMBER
      // <=> <7 compartments and Branch>7 are reduced to 0

        Resource lumber = input.copy ();
        lumber.processName = name ;
        lumber.wetBiomassBr0_4 = 0;
        lumber.wetBiomassBr4_7 = 0;
        lumber.wetBiomassBr7_more = 0;
        lumber.wetBiomassStem0_7 = 0;
        lumber.wetBiomassStem7_more_top = 0;
        lumber.wetBiomassLeaves = 0;
        lumber.status = ResourceStatus.LOG;
        lumber.market = MaterialMarketDestination.LUMBER;
        lumber.updateBiomasses (efficiency);
        lumber.updateMineralMasses ();
        lumber.addProcessInHistory (this);
        
        if(branchesMarketDestination.equals (MaterialMarketDestination.ENERGY)){
        // Branches and Stem<7 compartments are destined to energy
        // <=> only Stem>7 is reduced to 0
          Resource energy = input.copy ();
          energy.processName = name ;
          energy.wetBiomassStem7_more_bole = 0;
          energy.status = ResourceStatus.RESIDUAL;
          energy.market = MaterialMarketDestination.ENERGY;
          energy.updateBiomasses (efficiency);
          energy.updateMineralMasses ();
          energy.addProcessInHistory (this);
          
        // Energy costs are spread between lumber and energy
          double totalMass = energy.wetBiomass + lumber.wetBiomass;
          double energyPart = energy.wetBiomass / totalMass;
          double lumberPart = lumber.wetBiomass / totalMass;
        
          energy.machineWorkTime = harvestingTime_h * energyPart;
          energy.humanWorkTime = humanProductiveWorkTime * energyPart;
          energy.fuelConsumption = fuelConsumption * energyPart;
          energy.oilConsumption = oilConsumption * energyPart;
          energy.lcConsumption = lcConsumption * energyPart;
          energy.logisticsConsumption = logisticsConsumption * energyPart;
          energy.processConsumption = processConsumption * energyPart;
          energy.chainConsumption += processConsumption * energyPart;
          
          lumber.machineWorkTime = harvestingTime_h * lumberPart;
          lumber.humanWorkTime = humanProductiveWorkTime * lumberPart;
          lumber.fuelConsumption = fuelConsumption * lumberPart;
          lumber.oilConsumption = oilConsumption * lumberPart;
          lumber.lcConsumption = lcConsumption * lumberPart;
          lumber.logisticsConsumption = logisticsConsumption * lumberPart;
          lumber.processConsumption = processConsumption * lumberPart;
          lumber.chainConsumption += processConsumption * lumberPart;
        
        // Both resources are output
          outputs.add (energy);
          outputs.add (lumber);
          
        } else {
        // Only LUMBER is output
          outputs.add (lumber);
        }  
        
    } else if(stemMarketDestination.equals (MaterialMarketDestination.INDUSTRY)){
    
      // The Bole is destined to INDUSTRY
      // <=> <7 compartments and Branch>7 are reduced to 0
        Resource industry = input.copy ();
        industry.processName = name ;
        industry.wetBiomassBr0_4 = 0;
        industry.wetBiomassBr4_7 = 0;
        industry.wetBiomassBr7_more = 0;
        industry.wetBiomassStem0_7 = 0;
        industry.wetBiomassStem7_more_top = 0;
        industry.wetBiomassLeaves = 0;
        industry.status = ResourceStatus.LOG;
        industry.market = MaterialMarketDestination.INDUSTRY;
        industry.updateBiomasses (efficiency);
        industry.updateMineralMasses ();
        industry.addProcessInHistory (this);
        
        if(branchesMarketDestination.equals (MaterialMarketDestination.ENERGY)){
        // Branches and Stem<7 compartments are destined to energy
        // <=> only Stem>7 is reduced to 0
          Resource energy = input.copy ();
          energy.processName = name ;
          energy.wetBiomassStem7_more_bole = 0;
          energy.status = ResourceStatus.RESIDUAL;
          energy.market = MaterialMarketDestination.ENERGY;
          energy.updateBiomasses (efficiency);
          energy.updateMineralMasses ();
          energy.addProcessInHistory (this);
          
        // Energy costs are spread between industry and energy
          double totalMass = energy.wetBiomass + industry.wetBiomass;
          double energyPart = energy.wetBiomass / totalMass;
          double industryPart = industry.wetBiomass / totalMass;
        
          energy.machineWorkTime = harvestingTime_h * energyPart;
          energy.humanWorkTime = humanProductiveWorkTime * energyPart;
          energy.fuelConsumption = fuelConsumption * energyPart;
          energy.oilConsumption = oilConsumption * energyPart;
          energy.lcConsumption = lcConsumption * energyPart;
          energy.logisticsConsumption = logisticsConsumption * energyPart;
          energy.processConsumption = processConsumption * energyPart;
          energy.chainConsumption += processConsumption * energyPart;
          
          industry.machineWorkTime = harvestingTime_h * industryPart;
          industry.humanWorkTime = humanProductiveWorkTime * industryPart;
          industry.fuelConsumption = fuelConsumption * industryPart;
          industry.oilConsumption = oilConsumption * industryPart;
          industry.lcConsumption = lcConsumption * industryPart;
          industry.logisticsConsumption = logisticsConsumption * industryPart;
          industry.processConsumption = processConsumption * industryPart;
          industry.chainConsumption += processConsumption * industryPart;
          
        // Both resources are output
          outputs.add (energy);
          outputs.add (industry);
          
        } else {
        // Only INDUSTRY is output
          outputs.add (industry);
        }        
        
    } else if(stemMarketDestination.equals (MaterialMarketDestination.ENERGY)){

        Resource energy = input.copy ();
        
      if(branchesMarketDestination.equals (MaterialMarketDestination.ENERGY)){
  
      // The whole tree is destined to energy
        energy.status = ResourceStatus.FALLEN_TREE;
        energy.market = MaterialMarketDestination.ENERGY;
        energy.updateBiomasses (efficiency);
        energy.updateMineralMasses ();
        energy.addProcessInHistory (this);
        
      } else {
      // Only the Bole is destined to ENERGY
      // <=> <7 compartments and Branch>7 are reduced to 0
        energy.processName = name ;
        energy.wetBiomassBr0_4 = 0;
        energy.wetBiomassBr4_7 = 0;
        energy.wetBiomassBr7_more = 0;
        energy.wetBiomassStem0_7 = 0;
        energy.wetBiomassStem7_more_top = 0;
        energy.wetBiomassLeaves = 0;
        energy.status = ResourceStatus.LOG;
        energy.market = MaterialMarketDestination.ENERGY;
        energy.updateBiomasses (efficiency);
        energy.updateMineralMasses ();
        energy.addProcessInHistory (this);
        
      }
      
    // Energy costs are entirely destined to ENERGY
      energy.machineWorkTime = harvestingTime_h;
      energy.humanWorkTime = humanProductiveWorkTime ;
      energy.fuelConsumption = fuelConsumption ;
      energy.oilConsumption = oilConsumption ;
      energy.lcConsumption = lcConsumption ;
      energy.logisticsConsumption = logisticsConsumption ;
      energy.processConsumption = processConsumption ;
      energy.chainConsumption += processConsumption ;
      
    // ENERGY resource is output
      outputs.add (energy);
      
    }
    
	}

	public String toString () {
		return "HarvestingProcessBis" 
        + "name :" + name 
        + " movingSpeed:" + movingSpeed 
				+ " acquirePerf:" + acquirePerf
				+ " cuttingPerf:" + cuttingPerf
				+ " buckingPerf:" + buckingPerf
        + " stemMarketDestination:" + stemMarketDestination
        + " branchesMarketDestination:" + branchesMarketDestination        
        + " enginePower:" + enginePower
        + " workLoad_moving:" + workLoad_moving
        + " workLoad_acquiring:" + workLoad_acquiring
        + " workLoad_cutting:" + workLoad_cutting
        + " workLoad_bucking:" + workLoad_bucking
        + " machineWheight:" + machineWheight
        + " machineLifetime:" + machineLifetime
				+ " machineToHumanTimeRatio:" + machineToHumanTimeRatio
				+ " QGPlotDistance:" + QGPlotDistance;
	}

}
