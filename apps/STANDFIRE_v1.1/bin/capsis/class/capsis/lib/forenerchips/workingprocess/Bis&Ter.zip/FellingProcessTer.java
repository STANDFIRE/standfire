package capsis.lib.forenerchips.workingprocess;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.lib.forenerchips.Resource;
import capsis.lib.forenerchips.ResourceSite;
import capsis.lib.forenerchips.ResourceStatus;
import capsis.lib.forenerchips.MaterialMarketDestination;
import capsis.lib.forenerchips.WorkingProcess;

/**
 * A felling working process
 * 
 * @author N. Bilot - February 2013
 */
public class FellingProcessTer extends WorkingProcess {

  private String name;
	private boolean LeavesOn; // km
  private double efficiency; // ratio
  private double movingSpeed; // km/h
	private double acquirePerf; // mn/cm
	private double cuttingPerf; // mn/cm
  private double handlingPerf; // t/h
  private double enginePower; // kW
  private double workLoad_moving; // ratio
  private double workLoad_acquiring; // ratio
  private double workLoad_cutting; // ratio
  private double workLoad_handling; // ratio
  private String wholeTreeMarketDestination; // "ND", "ENERGY", "INDUSTRY", or "LUMBER
  private double machineWheight; // t
  private double machineLifetime; // h
  private double machineToHumanTimeRatio; // e.g. 1.5
	private boolean machineCarrierNeeded; // km
	private double QGPlotDistance; // km

	/**
	 * Constructor (Abatteuse simple, Tronconneur ou Abatteuse groupeuse). Choices in parameter
	 * inspired by Lortz (1997) : Manual felling time and productivity in southern pine forests
	 */
	public FellingProcessTer (String name, boolean LeavesOn, double efficiency, double movingSpeed, double acquirePerf, double cuttingPerf, double handlingPerf, double enginePower, double workLoad_moving, double workLoad_acquiring, double workLoad_cutting, double workLoad_handling, String wholeTreeMarketDestination, double machineWheight, double machineLifetime, double machineToHumanTimeRatio, boolean machineCarrierNeeded, double QGPlotDistance) throws Exception {
		super ("FellingProcessTer");

		// Check throws an exception if the condition is false
    check ("efficiency", efficiency >= 0);
    check ("efficiency", efficiency <= 1);
		check ("movingSpeed", movingSpeed >= 0);
		check ("acquirePerf", acquirePerf >= 0);
		check ("cuttingPerf", cuttingPerf >= 0);
    check ("handlingPerf", handlingPerf >= 0);
		check ("enginePower", enginePower >= 0);
    check ("workLoad_acquiring", workLoad_moving >= 0);
    check ("workLoad_acquiring", workLoad_moving <= 1);
    check ("workLoad_acquiring", workLoad_acquiring >= 0);
    check ("workLoad_acquiring", workLoad_acquiring <= 1);
    check ("workLoad_cutting", workLoad_cutting >= 0);
    check ("workLoad_cutting", workLoad_cutting <= 1);
    check ("workLoad_handling", workLoad_handling >= 0);
    check ("workLoad_handling", workLoad_handling <= 1);
    check ("wholeTreeMarketDestination", wholeTreeMarketDestination.equals (MaterialMarketDestination.ND) || wholeTreeMarketDestination.equals (MaterialMarketDestination.ENERGY) || wholeTreeMarketDestination.equals (MaterialMarketDestination.INDUSTRY) || wholeTreeMarketDestination.equals (MaterialMarketDestination.LUMBER));
    check ("machineWheight", machineWheight >= 0);
    check ("machineLifetime", machineLifetime >= 0);
		check ("machineToHumanTimeRatio", machineToHumanTimeRatio >= 0);
		check ("QGPlotDistance", QGPlotDistance >= 0);

		this.name = name;
		this.LeavesOn = LeavesOn;
    this.efficiency = efficiency;
    this.movingSpeed = movingSpeed;
		this.acquirePerf = acquirePerf;
		this.cuttingPerf = cuttingPerf;
    this.handlingPerf = handlingPerf;
		this.enginePower = enginePower;
    this.workLoad_moving = workLoad_moving;
    this.workLoad_acquiring = workLoad_acquiring;
    this.workLoad_cutting = workLoad_cutting;
    this.workLoad_handling = workLoad_handling;
    this.wholeTreeMarketDestination = wholeTreeMarketDestination;
    this.machineWheight = machineWheight;
    this.machineLifetime = machineLifetime;
		this.machineToHumanTimeRatio = machineToHumanTimeRatio;
		this.machineCarrierNeeded = machineCarrierNeeded;
		this.QGPlotDistance = QGPlotDistance;

		// What resource can be processed
		addCompatibleStatusOrSite (ResourceStatus.STANDING_TREE);
		addCompatibleStatusOrSite (ResourceSite.PLOT);

	}

	/**
	 * Creates an instance with all parameters in a single String, for scenarios in txt files.
	 */
	static public FellingProcessTer getInstance (String name, String parameters) throws Exception {
		StringTokenizer st = new StringTokenizer (parameters, " ");

    String wpName = name;
		boolean LeavesOn = booleanValue (st.nextToken ());
    double efficiency = doubleValue (st.nextToken ());
    double movingSpeed = doubleValue (st.nextToken ());
		double acquirePerf = doubleValue (st.nextToken ());
		double cuttingPerf = doubleValue (st.nextToken ());
    double handlingPerf = doubleValue (st.nextToken ());
		double enginePower = doubleValue (st.nextToken ());
    double workLoad_moving = doubleValue (st.nextToken ());
    double workLoad_acquiring = doubleValue (st.nextToken ());
    double workLoad_cutting = doubleValue (st.nextToken ());
    double workLoad_handling = doubleValue (st.nextToken ());
    String wholeTreeMarketDestination = st.nextToken ();
    double machineWheight = doubleValue (st.nextToken ());
    double machineLifetime = doubleValue (st.nextToken ());
		double machineToHumanTimeRatio = doubleValue (st.nextToken ());
		boolean machineCarrierNeeded = booleanValue (st.nextToken ());
		double QGPlotDistance = doubleValue (st.nextToken ());

		return new FellingProcessTer (name, LeavesOn, efficiency, movingSpeed, acquirePerf, cuttingPerf, handlingPerf, enginePower, workLoad_moving, workLoad_acquiring, workLoad_cutting, workLoad_handling, wholeTreeMarketDestination, machineWheight, machineLifetime, machineToHumanTimeRatio,	machineCarrierNeeded, QGPlotDistance);
	}

	/**
	 * Run the felling process
	 */
	@Override
	public void run () throws Exception {
		checkInputCompatibility ();

		// Outputs 1 resource: status FALLEN_TREE
		Resource output = input.copy ();
    output.processName = name ;

		output.status = ResourceStatus.FALLEN_TREE;
    // If the whole tree is destinated to energy, the market value is actualized. Else, this value is let to its default value ("ND")
    if (wholeTreeMarketDestination.equals (MaterialMarketDestination.ENERGY)){
      output.market = MaterialMarketDestination.ENERGY;
    }
    
    // Do the trees have leaves at the moment of the felling ?
    if(!LeavesOn){
      output.wetBiomassLeaves = 0;
      output.updateBiomasses (efficiency);
      output.updateMineralMasses ();
    }

		// Consumptions
		// 1. Fuel consumption
    double engineEfficiency = 0.35;
    
		double movingTime_h = ( (Math.sqrt (output.plotArea_ha * 10000) / Math.sqrt (output.treeNumber))
				/ (movingSpeed * 1000) ) * output.treeNumber; //
		double fuelConsumption_moving = movingTime_h * enginePower * workLoad_moving / engineEfficiency ;
    
    double acquireTime_h = ( acquirePerf * Math.pow (output.Dg / 2.54, 0.2) / 60d )  * output.treeNumber;
		double fuelConsumption_acquiring = acquireTime_h * enginePower * workLoad_acquiring /engineEfficiency ;
    
    double cuttingTime_h = ( cuttingPerf * Math.pow (output.Dg / 2.54, 0.937) / 60d )  * output.treeNumber;
    double fuelConsumption_cutting = cuttingTime_h * enginePower * workLoad_cutting / engineEfficiency;
    
    double handlingTime_h = (handlingPerf * output.wetBiomass) ;
    double fuelConsumption_handling = handlingTime_h * enginePower * workLoad_handling / engineEfficiency;
    
		double fuelConsumption = fuelConsumption_moving + fuelConsumption_acquiring + fuelConsumption_cutting + fuelConsumption_handling;
		
    // 2. Oil consumption
    double oilCoefficient = 0d;
    if(machineCarrierNeeded){
      oilCoefficient = 0.058;
    } else {
      oilCoefficient = 0.322;
    }
    double oilConsumption = fuelConsumption * oilCoefficient;
    
    // 3. Life Cycle consumption equivalent
    double lcConsumption_pert = 16556;
    
    double totalMachineTime_h = movingTime_h + acquireTime_h + cuttingTime_h;
    double lcConsumption_perh = machineWheight * lcConsumption_pert / machineLifetime;
    double lcConsumption = lcConsumption_perh * totalMachineTime_h;
    
    // 4. Logistics consumption
      // a. operatorTravelConsumption
      double humanProductiveWorkTime = totalMachineTime_h * machineToHumanTimeRatio;
      int humanProductiveWorkTime_day = (int) Math.ceil (humanProductiveWorkTime / WORKING_DAY_DURATION);
      double operatorTravelConsumption = QGPlotDistance * 2d * MEAN_CAR_CONSUMPTION * humanProductiveWorkTime_day; // kWh

      //  b. machineTravelConsumption
      double machineTravelConsumption = machineCarrierNeeded ? QGPlotDistance * 2d * MEAN_CARRIER_CONSUMPTION : 0d; // kWh
      
    double logisticsConsumption = operatorTravelConsumption + machineTravelConsumption;
    
    // PROCESS CONSUMPTION
    double processConsumption = fuelConsumption + oilConsumption + lcConsumption + logisticsConsumption;
    
		// Update the output resource
		output.machineWorkTime = totalMachineTime_h;
    output.humanWorkTime = humanProductiveWorkTime;
    output.fuelConsumption = fuelConsumption;
    output.oilConsumption = oilConsumption;
    output.lcConsumption = lcConsumption;
    output.logisticsConsumption = logisticsConsumption;
    output.processConsumption = processConsumption;
    output.chainConsumption += processConsumption;
    
		output.updateBiomasses (efficiency);
		output.updateMineralMasses ();
		output.addProcessInHistory (this);

		outputs.add (output);

	}

	public String toString () {
		return "FellingProcessTer" 
        + "name :" + name 
        + " LeavesOn:" + LeavesOn 
        + " efficiency:" + efficiency
        + " movingSpeed:" + movingSpeed 
				+ " acquirePerf:" + acquirePerf
				+ " cuttingPerf:" + cuttingPerf
        + " handlingPerf:" + handlingPerf
				+ " enginePower:" + enginePower
        + " workLoad_moving:" + workLoad_moving
        + " workLoad_acquiring:" + workLoad_acquiring
        + " workLoad_cutting:" + workLoad_cutting
        + " workLoad_handling:" + workLoad_handling
        + " wholeTreeMarketDestination:" + wholeTreeMarketDestination
        + " machineWheight:" + machineWheight
        + " machineLifetime:" + machineLifetime
				+ " machineToHumanTimeRatio:" + machineToHumanTimeRatio
				+ " machineCarrierNeeded:" + machineCarrierNeeded
				+ " QGPlotDistance:" + QGPlotDistance;
	}

}
