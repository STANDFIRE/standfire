package capsis.lib.forenerchips.workingprocess;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.lib.forenerchips.Resource;
import capsis.lib.forenerchips.ResourceSite;
import capsis.lib.forenerchips.ResourceStatus;
import capsis.lib.forenerchips.WorkingProcess;

/**
 * A forwarding working process (débardeur, porteur)
 * 
 * @author N. Bilot - February 2013
 */
public class ForwardingProcessTer extends WorkingProcess {

  private String name;
	private double volumeCapacity; // m3
	private double weightCapacity; // t
	private double handlingPerf; // mn/t
	private double movingSpeed; // km/h
	private double enginePower; // kW
  // private double workLoad_Full; // ratio
  // private double workLoad_Empty; // ratio
  private double workLoad_Handling; // ratio
  private double machineWheight; // t
  private double machineLifetime; // h
  private double machineToHumanTimeRatio; // e.g. 1.5
	private boolean machineCarrierNeeded; // km
	private double QGPlotDistance; // km



  
	/**
	 * Constructor.
	 */
	public ForwardingProcessTer (String name, double volumeCapacity, double weightCapacity, double handlingPerf, double movingSpeed, double enginePower, 
  // double workLoad_Full, double workLoad_Empty, 
  double workLoad_Handling, double machineWheight, double machineLifetime, double machineToHumanTimeRatio, boolean machineCarrierNeeded, double QGPlotDistance) throws Exception {
		super ("ForwardingProcessTer");

		// Check throws an exception if the condition is false
		check ("volumeCapacity", volumeCapacity >= 0);
		check ("weightCapacity", weightCapacity >= 0);
		check ("handlingPerf", handlingPerf >= 0);
		check ("movingSpeed", movingSpeed >= 0);
    check ("enginePower", enginePower >= 0);
		// check ("workLoad_Full", workLoad_Full >= 0);
    // check ("workLoad_Full", workLoad_Full <= 1);
    // check ("workLoad_Empty", workLoad_Empty >= 0);
    // check ("workLoad_Empty", workLoad_Empty <= 1);
    check ("workLoad_Handling", workLoad_Handling >= 0);
    check ("workLoad_Handling", workLoad_Handling <= 1);
    check ("machineWheight", machineWheight >= 0);
    check ("machineLifetime", machineLifetime >= 0);
		check ("machineToHumanTimeRatio", machineToHumanTimeRatio >= 0);
		check ("QGPlotDistance", QGPlotDistance >= 0);

		this.name = name;
		this.volumeCapacity = volumeCapacity;
		this.weightCapacity = weightCapacity;
		this.handlingPerf = handlingPerf;
		this.movingSpeed = movingSpeed;
    this.enginePower = enginePower;
		// this.workLoad_Full = workLoad_Full;
    // this.workLoad_Empty = workLoad_Empty;
    this.workLoad_Handling = workLoad_Handling;
    this.machineWheight = machineWheight;
    this.machineLifetime = machineLifetime;
		this.machineToHumanTimeRatio = machineToHumanTimeRatio;
		this.machineCarrierNeeded = machineCarrierNeeded;
		this.QGPlotDistance = QGPlotDistance;

		// What resource can be processed
		addCompatibleStatusOrSite (ResourceStatus.FALLEN_TREE);
		addCompatibleStatusOrSite (ResourceStatus.LOG);
		addCompatibleStatusOrSite (ResourceStatus.RESIDUAL);
		addCompatibleStatusOrSite (ResourceStatus.BUNDLE);
		addCompatibleStatusOrSite (ResourceStatus.BRANCH);
		addCompatibleStatusOrSite (ResourceSite.PLOT);

	}

	/**
	 * Creates an instance with all parameters in a single String, for scenarios in txt files.
	 */
	static public ForwardingProcessTer getInstance (String name, String parameters) throws Exception {
		StringTokenizer st = new StringTokenizer (parameters, " ");
		
    String wpName = name;
		double volumeCapacity = doubleValue (st.nextToken ());
		double weightCapacity = doubleValue (st.nextToken ());
		double handlingPerf = doubleValue (st.nextToken ());
		double movingSpeed = doubleValue (st.nextToken ());
    double enginePower = doubleValue (st.nextToken ());
		double workLoad_Handling = doubleValue (st.nextToken ());
    double machineWheight = doubleValue (st.nextToken ());
    double machineLifetime = doubleValue (st.nextToken ());
		double machineToHumanTimeRatio = doubleValue (st.nextToken ());
		boolean machineCarrierNeeded = booleanValue (st.nextToken ());
		double QGPlotDistance = doubleValue (st.nextToken ());
		
		return new ForwardingProcessTer (name, volumeCapacity, weightCapacity, handlingPerf, movingSpeed, enginePower, workLoad_Handling, machineWheight, machineLifetime, machineToHumanTimeRatio, machineCarrierNeeded, QGPlotDistance);
	}

	/**
	 * Run the forwarding process
	 */
	@Override
	public void run () throws Exception {
		checkInputCompatibility ();

		// Outputs 1 resource: same status, site: ROADSIDE
		Resource output = input.copy ();
    output.processName = name ;

		output.site = ResourceSite.ROADSIDE;

		// Efficiency
		double efficiency = 0;
		double bulkDensity = 0;
		if (input.status.equals (ResourceStatus.FALLEN_TREE)) {
			if (input.moistureContent >= 30d)
				efficiency = 0.9;
			else
				efficiency = 0.8;
			bulkDensity = 0.4;
		} else if (input.status.equals (ResourceStatus.BRANCH)) {
			if (input.moistureContent >= 30d)
				efficiency = 0.9;
			else
				efficiency = 0.8;
			bulkDensity = 0.4;
		} else if (input.status.equals (ResourceStatus.LOG)) {
			efficiency = 1;
			bulkDensity = 0.8;
		} else if (input.status.equals (ResourceStatus.RESIDUAL)) {
			if (input.moistureContent >= 30d)
				efficiency = 0.7;
			else
				efficiency = 0.6;
			bulkDensity = 0.3;
		} else if (input.status.equals (ResourceStatus.BUNDLE)) {
			efficiency = 1;
			bulkDensity = 0.8;
		}
		output.updateBiomasses (efficiency);

		// Consumptions
		// 1. fuelConsumption
      double engineEfficiency = 0.35;
      
      double biomassPerJourney = weightCapacity;
      if (weightCapacity / volumeCapacity >= bulkDensity) {
        biomassPerJourney = volumeCapacity * bulkDensity;
      }
      int numberOfJourneys = (int) Math.ceil (output.wetBiomass / biomassPerJourney);
      // The average distance is considered as half the transversal of a squared of the surface of the stand.
      // area_m2 = area_ha * 10000
      // squareSide = sqrt(area_m2)
      // transversale^2 = (squareSide^2)*2
      // avgDistance = sqrt(transversale^2) / 2
      double area_m2 = input.plotArea_ha * 10000d;
      double squaredSide = Math.sqrt(area_m2);
      double sqTransversal  = 2 * Math.pow(squaredSide, 2d);
      double avgDistance_m = Math.sqrt(sqTransversal) / 2d ;
      
      double movingTimeEmpty_h = numberOfJourneys * (avgDistance_m / 1000d) / movingSpeed; 
      double workLoad_Empty = machineWheight / (machineWheight + weightCapacity) ;
      double fuelConsumption_Empty = enginePower * engineEfficiency * workLoad_Empty * movingTimeEmpty_h;
            
      double movingTimeFull_h = numberOfJourneys * (avgDistance_m / 1000d) / movingSpeed;
      double workLoad_Full = machineWheight / (machineWheight + biomassPerJourney) ;
      double fuelConsumption_Full = enginePower * engineEfficiency * workLoad_Full * movingTimeFull_h;
            
      
      double handlingTime_h = numberOfJourneys * (biomassPerJourney * handlingPerf * 2d) / 60d;
      double fuelConsumption_Handling = enginePower * engineEfficiency * workLoad_Handling * handlingTime_h;
      
      double fuelConsumption = fuelConsumption_Empty + fuelConsumption_Full + fuelConsumption_Handling;
      
    // 2. Oil consumption
      double oilCoefficient = 0.033;
      double oilConsumption = fuelConsumption * oilCoefficient;
      
    // 3. Life Cycle consumption equivalent
      double lcConsumption_pert = 16556; // kWh/t
      double totalMachineTime_h = (movingTimeEmpty_h + movingTimeFull_h + handlingTime_h);
      double lcConsumption_perh = machineWheight * lcConsumption_pert / machineLifetime;
      double lcConsumption = lcConsumption_perh * totalMachineTime_h;
      
    // 4. Logistics consumption
      // a. operatorTravelConsumption
      double humanProductiveWorkTime = totalMachineTime_h * machineToHumanTimeRatio;
      int humanProductiveWorkTime_day = (int) Math.ceil (humanProductiveWorkTime / WORKING_DAY_DURATION);
      double operatorTravelConsumption = QGPlotDistance * 2d * MEAN_CAR_CONSUMPTION * humanProductiveWorkTime_day; // kWh

      //  b. machineTravelConsumption
		double machineTravelConsumption = machineCarrierNeeded ? QGPlotDistance * 2d * MEAN_CARRIER_CONSUMPTION : 0d; // kWh

    double logisticsConsumption = operatorTravelConsumption + machineTravelConsumption;
    
    // PROCESS CONSUMPTION
    double processConsumption = fuelConsumption + oilConsumption + lcConsumption + logisticsConsumption;
    
		// Update the output resource
		output.machineWorkTime = totalMachineTime_h;
    output.humanWorkTime = humanProductiveWorkTime;
    output.fuelConsumption = fuelConsumption;
    output.oilConsumption = oilConsumption;
    output.lcConsumption = lcConsumption;
    output.logisticsConsumption = logisticsConsumption;
    output.processConsumption = processConsumption;
    output.chainConsumption += processConsumption;
		output.updateMineralMasses ();
		output.addProcessInHistory (this);

		outputs.add (output);

	}

	public String toString () {
		return "ForwardingProcessTer" 
        + "name :" + name 
        + " volumeCapacity:" + volumeCapacity 
				+ " weightCapacity:" + weightCapacity
				+ " handlingPerf:" + handlingPerf
				+ " movingSpeed:" + movingSpeed
        + " enginePower:" + enginePower
				// + " workLoad_Full:" + workLoad_Full
        // + " workLoad_Empty:" + workLoad_Empty
        + " workLoad_Handling:" + workLoad_Handling
        + " machineWheight:" + machineWheight
        + " machineLifetime:" + machineLifetime
				+ " machineToHumanTimeRatio:" + machineToHumanTimeRatio
				+ " machineCarrierNeeded:" + machineCarrierNeeded
				+ " QGPlotDistance:" + QGPlotDistance;
	}

}
