package capsis.lib.forenerchips.workingprocess;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.lib.forenerchips.Resource;
import capsis.lib.forenerchips.ResourceSite;
import capsis.lib.forenerchips.MaterialMarketDestination;
import capsis.lib.forenerchips.ResourceStatus;
import capsis.lib.forenerchips.WorkingProcess;

/**
 * A bucking working process (faconneuse)
 * 
 * @author N. Bilot - February 2013
 */
public class BuckingProcessBis extends WorkingProcess {

  private String name;
	private double buckingPerf; // t/h
  private double efficiency; // kW
  private double enginePower; // kW
  private double workLoad; // ratio
  private double machineWheight; // t
  private double machineLifetime; // h
  private String stemMarketDestination; // "ND", "ENERGY", "INDUSTRY", or "LUMBER
  private String branchesMarketDestination; // "ND", "ENERGY", "INDUSTRY", or "LUMBER
  private String smallWoodMarketDestination; // "ND", "ENERGY", "INDUSTRY", or "LUMBER
	private double machineToHumanTimeRatio; // e.g. 1.5
	private boolean machineCarrierNeeded; // km
	private double QGPlotDistance; // km


	/**
	 * Constructor.
	 */
   public BuckingProcessBis (String name, double buckingPerf, double efficiency, double enginePower, double workLoad, double machineWheight, double machineLifetime, String stemMarketDestination, String branchesMarketDestination, String smallWoodMarketDestination, double machineToHumanTimeRatio, boolean machineCarrierNeeded, double QGPlotDistance) throws Exception {
		super ("BuckingProcessBis");

		// Check throws an exception if the condition is false
		check ("buckingPerf", buckingPerf >= 0);
    check ("efficiency", efficiency >= 0);
		check ("enginePower", enginePower >= 0);
    check ("workLoad", workLoad >= 0);
    check ("workLoad", workLoad <= 1);
    check ("machineWheight", machineWheight >= 0);
    check ("machineLifetime", machineLifetime >= 0);
		check ("machineToHumanTimeRatio", machineToHumanTimeRatio >= 0);
		check ("QGPlotDistance", QGPlotDistance >= 0);
    check ("stemMarketDestination", stemMarketDestination.equals (MaterialMarketDestination.ND) || stemMarketDestination.equals (MaterialMarketDestination.ENERGY) || stemMarketDestination.equals (MaterialMarketDestination.INDUSTRY) || stemMarketDestination.equals (MaterialMarketDestination.LUMBER));
    check ("branchesMarketDestination", branchesMarketDestination.equals (MaterialMarketDestination.ND) || branchesMarketDestination.equals (MaterialMarketDestination.ENERGY) || branchesMarketDestination.equals (MaterialMarketDestination.INDUSTRY) || branchesMarketDestination.equals (MaterialMarketDestination.LUMBER));
    check ("smallWoodMarketDestination", smallWoodMarketDestination.equals (MaterialMarketDestination.ND) || smallWoodMarketDestination.equals (MaterialMarketDestination.ENERGY) || smallWoodMarketDestination.equals (MaterialMarketDestination.INDUSTRY) || smallWoodMarketDestination.equals (MaterialMarketDestination.LUMBER));

		this.name = name;
		this.buckingPerf = buckingPerf;
    this.efficiency = efficiency;
    this.enginePower = enginePower;
		this.workLoad = workLoad;
    this.machineWheight = machineWheight;
    this.machineLifetime = machineLifetime;
    this.stemMarketDestination = stemMarketDestination;
    this.branchesMarketDestination = branchesMarketDestination;
    this.smallWoodMarketDestination = smallWoodMarketDestination;
		this.machineToHumanTimeRatio = machineToHumanTimeRatio;
		this.machineCarrierNeeded = machineCarrierNeeded;
		this.QGPlotDistance = QGPlotDistance;

		// What resource can be processed
		addCompatibleStatusOrSite (ResourceStatus.FALLEN_TREE);
    addCompatibleStatusOrSite (ResourceStatus.BRANCH);
		addCompatibleStatusOrSite (ResourceSite.PLOT);
		addCompatibleStatusOrSite (ResourceSite.ROADSIDE);

	}

	/**
	 * Creates an instance with all parameters in a single String, for scenarios in txt files.
	 */
	static public BuckingProcessBis getInstance (String name, String parameters) throws Exception {
		StringTokenizer st = new StringTokenizer (parameters, " ");
		
    String wpName = name;
		double buckingPerf = doubleValue (st.nextToken ());
    double efficiency = doubleValue (st.nextToken ());
		double enginePower = doubleValue (st.nextToken ());
    double workLoad = doubleValue (st.nextToken ());
    double machineWheight = doubleValue (st.nextToken ());
    double machineLifetime = doubleValue (st.nextToken ());
    
    String stemMarketDestination = st.nextToken ();
    if (stemMarketDestination.equals ("LUMBER")) 
			stemMarketDestination = MaterialMarketDestination.LUMBER;
		else if (stemMarketDestination.equals ("INDUSTRY")) 
			stemMarketDestination = MaterialMarketDestination.INDUSTRY;
    else if (stemMarketDestination.equals ("ENERGY")) 
			stemMarketDestination = MaterialMarketDestination.ENERGY;
    else if (stemMarketDestination.equals ("ND")) 
			stemMarketDestination = MaterialMarketDestination.ND;
		else 
			throw new Exception ("MaterialMarketDestination: wrong value for stemMarketDestination: "+stemMarketDestination+", must be LUMBER, INDUSTRY, ENERGY or ND");
    String branchesMarketDestination = st.nextToken ();
    if (branchesMarketDestination.equals ("LUMBER")) 
			branchesMarketDestination = MaterialMarketDestination.LUMBER;
		else if (branchesMarketDestination.equals ("INDUSTRY")) 
			branchesMarketDestination = MaterialMarketDestination.INDUSTRY;
    else if (branchesMarketDestination.equals ("ENERGY")) 
			branchesMarketDestination = MaterialMarketDestination.ENERGY;
    else if (branchesMarketDestination.equals ("ND")) 
			branchesMarketDestination = MaterialMarketDestination.ND;
    else 
			throw new Exception ("MaterialMarketDestination: wrong value for branchesMarketDestination: "+branchesMarketDestination+", must be LUMBER, INDUSTRY, ENERGY or ND");
      
    String smallWoodMarketDestination = st.nextToken ();
    if (smallWoodMarketDestination.equals ("LUMBER")) 
			smallWoodMarketDestination = MaterialMarketDestination.LUMBER;
		else if (smallWoodMarketDestination.equals ("INDUSTRY")) 
			smallWoodMarketDestination = MaterialMarketDestination.INDUSTRY;
    else if (smallWoodMarketDestination.equals ("ENERGY")) 
			smallWoodMarketDestination = MaterialMarketDestination.ENERGY;
    else if (smallWoodMarketDestination.equals ("ND")) 
			smallWoodMarketDestination = MaterialMarketDestination.ND;
    else 
			throw new Exception ("MaterialMarketDestination: wrong value for smallWoodMarketDestination: "+smallWoodMarketDestination+", must be LUMBER, INDUSTRY, ENERGY or ND");
      
		double machineToHumanTimeRatio = doubleValue (st.nextToken ());
		boolean machineCarrierNeeded = booleanValue (st.nextToken ());
		double QGPlotDistance = doubleValue (st.nextToken ());
		
		return new BuckingProcessBis (name, buckingPerf, efficiency, enginePower, workLoad, machineWheight, machineLifetime, stemMarketDestination, branchesMarketDestination, smallWoodMarketDestination, machineToHumanTimeRatio, machineCarrierNeeded, QGPlotDistance);
	}

	/**
	 * Run the bucking process
	 */
	@Override
	public void run () throws Exception {
		checkInputCompatibility ();

		
    // Consumptions
		// 1. fuelConsumption
      double engineEfficiency = 0.35;
		
      double buckingTime_h = input.wetBiomass / buckingPerf;
      double hourlyConsumption = (enginePower * workLoad) / engineEfficiency;
      double fuelConsumption = hourlyConsumption * buckingTime_h;
    
    // 2. Oil consumption
    double oilCoefficient = 0d;
    if(machineCarrierNeeded){
      oilCoefficient = 0.058;
    } else {
      oilCoefficient = 0.322;
    }
      double oilConsumption = fuelConsumption * oilCoefficient;
    
    // 3. Life Cycle consumption equivalent
      double lcConsumption_pert = 16556;
      double lcConsumption_perh = machineWheight * lcConsumption_pert / machineLifetime;
      double lcConsumption = lcConsumption_perh * buckingTime_h;

    // 4. Logistics consumption
      // a. operatorTravelConsumption
      double humanProductiveWorkTime = buckingTime_h * machineToHumanTimeRatio;
      int humanProductiveWorkTime_day = (int) Math.ceil (humanProductiveWorkTime / WORKING_DAY_DURATION);
      double operatorTravelConsumption = QGPlotDistance * 2d * MEAN_CAR_CONSUMPTION * humanProductiveWorkTime_day; // kWh

      //  b. machineTravelConsumption
      double machineTravelConsumption = machineCarrierNeeded ? QGPlotDistance * 2d * MEAN_CARRIER_CONSUMPTION : 0d; // kWh

    double logisticsConsumption = operatorTravelConsumption + machineTravelConsumption;

    // PROCESS CONSUMPTION
    double processConsumption = fuelConsumption + oilConsumption + lcConsumption + logisticsConsumption;

       
    // Outputs material(s)
		if (stemMarketDestination.equals (MaterialMarketDestination.LUMBER)) {
    
      if (branchesMarketDestination.equals (stemMarketDestination)) {
      
      // The stem and branches >7cm are destined to lumber
      // <=> <7 compartments and leaves are reduced to 0
        Resource lumber = input.copy ();
        lumber.processName = name ;
        lumber.wetBiomassBr0_4 = 0;
        lumber.wetBiomassBr4_7 = 0;
        lumber.wetBiomassStem0_7 = 0;
        lumber.wetBiomassLeaves = 0;
        lumber.status = ResourceStatus.LOG;
        lumber.market = MaterialMarketDestination.LUMBER;
        lumber.updateBiomasses (efficiency);
        lumber.updateMineralMasses ();
        lumber.addProcessInHistory (this);
        
        if (smallWoodMarketDestination.equals (MaterialMarketDestination.ENERGY)){
        
        // SmallWood compartments are destined to energy
        // <=> Branch>7 and Stem>7 are reduced to 0
          Resource energy = input.copy ();
          energy.processName = name ;
          energy.wetBiomassBr7_more = 0;
          energy.wetBiomassStem7_more_top = 0;
          energy.wetBiomassStem7_more_bole = 0;
          energy.status = ResourceStatus.RESIDUAL;
          energy.market = MaterialMarketDestination.ENERGY;
          energy.updateBiomasses (efficiency);
          energy.updateMineralMasses ();
          energy.addProcessInHistory (this);
         
        // energy costs are spread between lumber and energy destinations 
          double totalMass = energy.wetBiomass + lumber.wetBiomass ;
          double energyPart = energy.wetBiomass / totalMass;
          double lumberPart = lumber.wetBiomass / totalMass;
          
          energy.machineWorkTime = buckingTime_h * energyPart;
          energy.humanWorkTime = humanProductiveWorkTime * energyPart;
          energy.fuelConsumption = fuelConsumption * energyPart;
          energy.oilConsumption = oilConsumption * energyPart;
          energy.lcConsumption = lcConsumption * energyPart;
          energy.logisticsConsumption = logisticsConsumption * energyPart;
          energy.processConsumption = processConsumption * energyPart;
          energy.chainConsumption += processConsumption * energyPart;
          
          lumber.machineWorkTime = buckingTime_h * lumberPart;
          lumber.humanWorkTime = humanProductiveWorkTime * lumberPart;
          lumber.fuelConsumption = fuelConsumption * lumberPart;
          lumber.oilConsumption = oilConsumption * lumberPart;
          lumber.lcConsumption = lcConsumption * lumberPart;
          lumber.logisticsConsumption = logisticsConsumption * lumberPart;
          lumber.processConsumption = processConsumption * lumberPart;
          lumber.chainConsumption += processConsumption * lumberPart;
          
          outputs.add (energy);
          outputs.add (lumber);
          
          
          
        } else { 
        
        // The whole energy costs are endorsed by lumber
          lumber.machineWorkTime = buckingTime_h;
          lumber.humanWorkTime = humanProductiveWorkTime;
          lumber.fuelConsumption = fuelConsumption;
          lumber.oilConsumption = oilConsumption;
          lumber.lcConsumption = lcConsumption;
          lumber.logisticsConsumption = logisticsConsumption;
          lumber.processConsumption = processConsumption;
          lumber.chainConsumption += processConsumption;
          
          outputs.add (lumber);
         
        }
        
      } else if (branchesMarketDestination != MaterialMarketDestination.LUMBER) {

      // Only the bole is destined to LUMBER
      // <=> <7 and Branch>7 are reduced to 0
        Resource lumber = input.copy ();
        lumber.processName = name ;
        lumber.wetBiomassBr0_4 = 0;
        lumber.wetBiomassBr4_7 = 0;
        lumber.wetBiomassBr7_more = 0;
        lumber.wetBiomassStem0_7 = 0;
        lumber.wetBiomassStem7_more_top = 0;
        lumber.wetBiomassLeaves = 0;
        lumber.status = ResourceStatus.LOG;
        lumber.market = MaterialMarketDestination.LUMBER;
        lumber.updateBiomasses (efficiency);
        lumber.updateMineralMasses ();
        lumber.addProcessInHistory (this);
     
        if (branchesMarketDestination.equals (MaterialMarketDestination.INDUSTRY)) {
          
        // As smallwood cannot be destined to industry, only branches >7cm are destined to INDUSTRY
        // <=> bole, <7 compartments and leaves are reduced to 0
          Resource industry = input.copy ();
          industry.processName = name ;
          industry.wetBiomassStem7_more_bole = 0;
          industry.wetBiomassBr0_4 = 0;
          industry.wetBiomassBr4_7 = 0;
          industry.wetBiomassStem0_7 = 0;
          industry.wetBiomassLeaves = 0;
          industry.status = ResourceStatus.LOG;
          industry.market = MaterialMarketDestination.INDUSTRY;
          industry.updateBiomasses (efficiency);
          industry.updateMineralMasses ();
          industry.addProcessInHistory (this);
          
          if (smallWoodMarketDestination.equals (MaterialMarketDestination.ENERGY)){
          
          // Smallwood compartments are destined to ENERGY
          // <=> >7 compartments are reduces to 0
            Resource energy = input.copy ();
            energy.processName = name ;
            energy.wetBiomassBr7_more = 0;
            energy.wetBiomassStem7_more_top = 0;
            energy.wetBiomassStem7_more_bole = 0;
            energy.status = ResourceStatus.RESIDUAL;
            energy.market = MaterialMarketDestination.ENERGY;
            energy.updateBiomasses (efficiency);
            energy.updateMineralMasses ();
            energy.addProcessInHistory (this);
              
          // energy costs are spread between the three products
            double totalMass = energy.wetBiomass + industry.wetBiomass + lumber.wetBiomass ;
            double energyPart = energy.wetBiomass / totalMass;
            double industryPart = industry.wetBiomass / totalMass;
            double lumberPart = lumber.wetBiomass / totalMass;
            
            energy.machineWorkTime = buckingTime_h * energyPart;
            energy.humanWorkTime = humanProductiveWorkTime * energyPart;
            energy.fuelConsumption = fuelConsumption * energyPart;
            energy.oilConsumption = oilConsumption * energyPart;
            energy.lcConsumption = lcConsumption * energyPart;
            energy.logisticsConsumption = logisticsConsumption * energyPart;
            energy.processConsumption = processConsumption * energyPart;
            energy.chainConsumption += processConsumption * energyPart;
           
            industry.machineWorkTime = buckingTime_h * industryPart;
            industry.humanWorkTime = humanProductiveWorkTime * industryPart;
            industry.fuelConsumption = fuelConsumption * industryPart;
            industry.oilConsumption = oilConsumption * industryPart;
            industry.lcConsumption = lcConsumption * industryPart;
            industry.logisticsConsumption = logisticsConsumption * industryPart;
            industry.processConsumption = processConsumption * industryPart;
            industry.chainConsumption += processConsumption * industryPart;
            
            lumber.machineWorkTime = buckingTime_h * lumberPart;
            lumber.humanWorkTime = humanProductiveWorkTime * lumberPart;
            lumber.fuelConsumption = fuelConsumption * lumberPart;
            lumber.oilConsumption = oilConsumption * lumberPart;
            lumber.lcConsumption = lcConsumption * lumberPart;
            lumber.logisticsConsumption = logisticsConsumption * lumberPart;
            lumber.processConsumption = processConsumption * lumberPart;
            lumber.chainConsumption += processConsumption * lumberPart;
            
            outputs.add (energy);
            outputs.add (industry);
            outputs.add (lumber);
            
           
          } else {
          
          //Energy costs are spread between lumber and industry products
            double totalMass = industry.wetBiomass + lumber.wetBiomass ;
            double industryPart = industry.wetBiomass / totalMass;
            double lumberPart = lumber.wetBiomass / totalMass;
            
            industry.machineWorkTime = buckingTime_h * industryPart;
            industry.humanWorkTime = humanProductiveWorkTime * industryPart;
            industry.fuelConsumption = fuelConsumption * industryPart;
            industry.oilConsumption = oilConsumption * industryPart;
            industry.lcConsumption = lcConsumption * industryPart;
            industry.logisticsConsumption = logisticsConsumption * industryPart;
            industry.processConsumption = processConsumption * industryPart;
            industry.chainConsumption += processConsumption * industryPart;
            
            lumber.machineWorkTime = buckingTime_h * lumberPart;
            lumber.humanWorkTime = humanProductiveWorkTime * lumberPart;
            lumber.fuelConsumption = fuelConsumption * lumberPart;
            lumber.oilConsumption = oilConsumption * lumberPart;
            lumber.lcConsumption = lcConsumption * lumberPart;
            lumber.logisticsConsumption = logisticsConsumption * lumberPart;
            lumber.processConsumption = processConsumption * lumberPart;
            lumber.chainConsumption += processConsumption * lumberPart;
            
            outputs.add (industry);
            outputs.add (lumber);
            
          }
            
        } else if (branchesMarketDestination.equals (MaterialMarketDestination.ENERGY)){
            
          if (smallWoodMarketDestination.equals (MaterialMarketDestination.ENERGY)){
          
          // SmallWood and Branch>7 compartments are destined to energy
          // <=> Stem>7 is reduced to 0
            Resource energy = input.copy ();
            energy.processName = name ;
            energy.wetBiomassStem7_more_bole = 0;
            energy.status = ResourceStatus.BRANCH;
            energy.market = MaterialMarketDestination.ENERGY;
            energy.updateBiomasses (efficiency);
            energy.updateMineralMasses ();
            energy.addProcessInHistory (this);
            
          // Energy costs are spread between Lumber and Energy
            double totalMass = lumber.wetBiomass + energy.wetBiomass ;
            double lumberPart = lumber.wetBiomass / totalMass;
            double energyPart = energy.wetBiomass / totalMass;
            
            lumber.machineWorkTime = buckingTime_h * lumberPart;
            lumber.humanWorkTime = humanProductiveWorkTime * lumberPart;
            lumber.fuelConsumption = fuelConsumption * lumberPart;
            lumber.oilConsumption = oilConsumption * lumberPart;
            lumber.lcConsumption = lcConsumption * lumberPart;
            lumber.logisticsConsumption = logisticsConsumption * lumberPart;
            lumber.processConsumption = processConsumption * lumberPart;
            lumber.chainConsumption += processConsumption * lumberPart;
            
            energy.machineWorkTime = buckingTime_h * energyPart;
            energy.humanWorkTime = humanProductiveWorkTime * energyPart;
            energy.fuelConsumption = fuelConsumption * energyPart;
            energy.oilConsumption = oilConsumption * energyPart;
            energy.lcConsumption = lcConsumption * energyPart;
            energy.logisticsConsumption = logisticsConsumption * energyPart;
            energy.processConsumption = processConsumption * energyPart;
            energy.chainConsumption += processConsumption * energyPart;
            
            outputs.add (lumber);
            outputs.add (energy);
          
            
          } else {
            
          // Only Branch>7 is destined to energy
          // <=> <7 compartments, leaves and bole are reduced to 0
            Resource energy = input.copy ();
            energy.processName = name ;
            energy.wetBiomassBr0_4 = 0;
            energy.wetBiomassBr4_7 = 0;
            energy.wetBiomassStem7_more_bole = 0;
            energy.wetBiomassStem0_7 = 0;
            energy.wetBiomassLeaves = 0;
            energy.status = ResourceStatus.LOG;
            energy.market = MaterialMarketDestination.ENERGY;
            energy.updateBiomasses (efficiency);
            energy.updateMineralMasses ();
            energy.addProcessInHistory (this);
            
          // Energy costs are spread between Lumber and Energy
            double totalMass = lumber.wetBiomass + energy.wetBiomass ;
            double lumberPart = lumber.wetBiomass / totalMass;
            double energyPart = energy.wetBiomass / totalMass;
            
            lumber.machineWorkTime = buckingTime_h * lumberPart;
            lumber.humanWorkTime = humanProductiveWorkTime * lumberPart;
            lumber.fuelConsumption = fuelConsumption * lumberPart;
            lumber.oilConsumption = oilConsumption * lumberPart;
            lumber.lcConsumption = lcConsumption * lumberPart;
            lumber.logisticsConsumption = logisticsConsumption * lumberPart;
            lumber.processConsumption = processConsumption * lumberPart;
            lumber.chainConsumption += processConsumption * lumberPart;
            
            energy.machineWorkTime = buckingTime_h * energyPart;
            energy.humanWorkTime = humanProductiveWorkTime * energyPart;
            energy.fuelConsumption = fuelConsumption * energyPart;
            energy.oilConsumption = oilConsumption * energyPart;
            energy.lcConsumption = lcConsumption * energyPart;
            energy.logisticsConsumption = logisticsConsumption * energyPart;
            energy.processConsumption = processConsumption * energyPart;
            energy.chainConsumption += processConsumption * energyPart;
            
            outputs.add (lumber);
            outputs.add (energy);
              
          }
        
        }
           
      }
        
    } else if (stemMarketDestination.equals (MaterialMarketDestination.INDUSTRY)) {
    
      if (branchesMarketDestination.equals (stemMarketDestination)) {
      
      // As smallwood cannot be destined to industry, only branches>7 and stem >7cm are destined to INDUSTRY
      // <=> <7 compartments and leaves are reduced to 0
        Resource industry = input.copy ();
        industry.processName = name ;
        industry.wetBiomassBr0_4 = 0;
        industry.wetBiomassBr4_7 = 0;
        industry.wetBiomassStem0_7 = 0;
        industry.wetBiomassLeaves = 0;
        industry.status = ResourceStatus.LOG;
        industry.market = MaterialMarketDestination.INDUSTRY;
        industry.updateBiomasses (efficiency);
        industry.updateMineralMasses ();
        industry.addProcessInHistory (this);
    
        if (smallWoodMarketDestination.equals (MaterialMarketDestination.ENERGY)){
        
        // Smallwood is destined to energy
        // <=> >7 compartments are reduced to 0
          Resource energy = input.copy ();
          energy.processName = name ;
          energy.wetBiomassBr7_more = 0;
          energy.wetBiomassStem7_more_top = 0;
          energy.wetBiomassStem7_more_bole = 0;
          energy.status = ResourceStatus.BRANCH;
          energy.market = MaterialMarketDestination.ENERGY;
          energy.updateBiomasses (efficiency);
          energy.updateMineralMasses ();
          energy.addProcessInHistory (this);
          
        // energy costs are spread between industry and energy
          double totalMass = industry.wetBiomass + energy.wetBiomass ;
          double industryPart = industry.wetBiomass / totalMass;
          double energyPart = energy.wetBiomass / totalMass;
          
          industry.machineWorkTime = buckingTime_h * industryPart;
          industry.humanWorkTime = humanProductiveWorkTime * industryPart;
          industry.fuelConsumption = fuelConsumption * industryPart;
          industry.oilConsumption = oilConsumption * industryPart;
          industry.lcConsumption = lcConsumption * industryPart;
          industry.logisticsConsumption = logisticsConsumption * industryPart;
          industry.processConsumption = processConsumption * industryPart;
          industry.chainConsumption += processConsumption * industryPart;
          
          energy.machineWorkTime = buckingTime_h * energyPart;
          energy.humanWorkTime = humanProductiveWorkTime * energyPart;
          energy.fuelConsumption = fuelConsumption * energyPart;
          energy.oilConsumption = oilConsumption * energyPart;
          energy.lcConsumption = lcConsumption * energyPart;
          energy.logisticsConsumption = logisticsConsumption * energyPart;
          energy.processConsumption = processConsumption * energyPart;
          energy.chainConsumption += processConsumption * energyPart;
          
          outputs.add (industry);
          outputs.add (energy);
        
        } else {
        
        // energy costs are entirely endorsed by industry
          industry.machineWorkTime = buckingTime_h;
          industry.humanWorkTime = humanProductiveWorkTime;
          industry.fuelConsumption = fuelConsumption;
          industry.oilConsumption = oilConsumption;
          industry.lcConsumption = lcConsumption;
          industry.logisticsConsumption = logisticsConsumption;
          industry.processConsumption = processConsumption;
          industry.chainConsumption += processConsumption;
          
          outputs.add (industry);          
          
        }
        
      } else if (branchesMarketDestination.equals (MaterialMarketDestination.ENERGY)){
        
      // Only bole in destined to industry
      // <=> <7 compartments, leaves and Branch>7 are reduced to 0
        Resource industry = input.copy ();
        industry.processName = name ;
        industry.wetBiomassBr0_4 = 0;
        industry.wetBiomassBr4_7 = 0;
        industry.wetBiomassBr7_more = 0;
        industry.wetBiomassStem0_7 = 0;
        industry.wetBiomassStem7_more_top = 0;
        industry.wetBiomassLeaves = 0;
        industry.status = ResourceStatus.LOG;
        industry.market = MaterialMarketDestination.INDUSTRY;
        industry.updateBiomasses (efficiency);
        industry.updateMineralMasses ();
        industry.addProcessInHistory (this);
        
        if (smallWoodMarketDestination.equals (MaterialMarketDestination.ENERGY)){
        
        // Entire Branches and Stem<7 are destined to energy
        // <=> bole is reduced to 0
          Resource energy = input.copy ();
          energy.processName = name ;
          energy.wetBiomassStem7_more_bole = 0;
          energy.status = ResourceStatus.BRANCH;
          energy.market = MaterialMarketDestination.ENERGY;
          energy.updateBiomasses (efficiency);
          energy.updateMineralMasses ();
          energy.addProcessInHistory (this);
          
        // energy costs are spread between industry and energy
          double totalMass = industry.wetBiomass + energy.wetBiomass ;
          double industryPart = industry.wetBiomass / totalMass;
          double energyPart = energy.wetBiomass / totalMass;
          
          industry.machineWorkTime = buckingTime_h * industryPart;
          industry.humanWorkTime = humanProductiveWorkTime * industryPart;
          industry.fuelConsumption = fuelConsumption * industryPart;
          industry.oilConsumption = oilConsumption * industryPart;
          industry.lcConsumption = lcConsumption * industryPart;
          industry.logisticsConsumption = logisticsConsumption * industryPart;
          industry.processConsumption = processConsumption * industryPart;
          industry.chainConsumption += processConsumption * industryPart;
          
          energy.machineWorkTime = buckingTime_h * energyPart;
          energy.humanWorkTime = humanProductiveWorkTime * energyPart;
          energy.fuelConsumption = fuelConsumption * energyPart;
          energy.oilConsumption = oilConsumption * energyPart;
          energy.lcConsumption = lcConsumption * energyPart;
          energy.logisticsConsumption = logisticsConsumption * energyPart;
          energy.processConsumption = processConsumption * energyPart;
          energy.chainConsumption += processConsumption * energyPart;
          
          outputs.add (industry);
          outputs.add (energy); 
          
        } else if (smallWoodMarketDestination.equals (MaterialMarketDestination.ND)){
        
        // Only Branch>7 is destined to energy
        // <=> <7 compartments, leaves and bole are reduced to 0
          Resource energy = input.copy ();
          energy.processName = name ;
          energy.wetBiomassBr0_4 = 0;
          energy.wetBiomassBr4_7 = 0;
          energy.wetBiomassStem7_more_bole = 0;
          energy.wetBiomassStem0_7 = 0;
          energy.wetBiomassLeaves = 0;
          energy.status = ResourceStatus.LOG;
          energy.market = MaterialMarketDestination.ENERGY;
          energy.updateBiomasses (efficiency);
          energy.updateMineralMasses ();
          energy.addProcessInHistory (this);
          
        // energy costs are spread between industry and energy
          double totalMass = industry.wetBiomass + energy.wetBiomass ;
          double industryPart = industry.wetBiomass / totalMass;
          double energyPart = energy.wetBiomass / totalMass;
          
          industry.machineWorkTime = buckingTime_h * industryPart;
          industry.humanWorkTime = humanProductiveWorkTime * industryPart;
          industry.fuelConsumption = fuelConsumption * industryPart;
          industry.oilConsumption = oilConsumption * industryPart;
          industry.lcConsumption = lcConsumption * industryPart;
          industry.logisticsConsumption = logisticsConsumption * industryPart;
          industry.processConsumption = processConsumption * industryPart;
          industry.chainConsumption += processConsumption * industryPart;
          
          energy.machineWorkTime = buckingTime_h * energyPart;
          energy.humanWorkTime = humanProductiveWorkTime * energyPart;
          energy.fuelConsumption = fuelConsumption * energyPart;
          energy.oilConsumption = oilConsumption * energyPart;
          energy.lcConsumption = lcConsumption * energyPart;
          energy.logisticsConsumption = logisticsConsumption * energyPart;
          energy.processConsumption = processConsumption * energyPart;
          energy.chainConsumption += processConsumption * energyPart;
          
          outputs.add (industry);
          outputs.add (energy); 

        }
        
      } else {
      
      // Only Stem>7 in destined to Industry 
      // <=> Branch>7, <7 compartments and leaves are reduced to 0
        Resource industry = input.copy ();
        industry.processName = name ;
        industry.wetBiomassBr7_more = 0;
        industry.wetBiomassBr0_4 = 0;
        industry.wetBiomassBr4_7 = 0;
        industry.wetBiomassStem0_7 = 0;
        industry.wetBiomassStem7_more_top = 0;
        industry.wetBiomassLeaves = 0;
        industry.status = ResourceStatus.LOG;
        industry.market = MaterialMarketDestination.INDUSTRY;
        industry.updateBiomasses (efficiency);
        industry.updateMineralMasses ();
        industry.addProcessInHistory (this);
      
      // energy costs are entirely endorsed by industry
        industry.machineWorkTime = buckingTime_h;
        industry.humanWorkTime = humanProductiveWorkTime;
        industry.fuelConsumption = fuelConsumption;
        industry.oilConsumption = oilConsumption;
        industry.lcConsumption = lcConsumption;
        industry.logisticsConsumption = logisticsConsumption;
        industry.processConsumption = processConsumption;
        industry.chainConsumption += processConsumption;
        
        outputs.add (industry);

      }
    
    } else if (stemMarketDestination.equals (MaterialMarketDestination.ENERGY)) {
      
      if (branchesMarketDestination.equals (MaterialMarketDestination.ENERGY)){
        
        if (smallWoodMarketDestination.equals (MaterialMarketDestination.ENERGY)){
          
        // The whole trees are destined to energy
        // Nothing is reduced to 0
          Resource energy = input.copy ();
          energy.processName = name ;
          energy.status = ResourceStatus.FALLEN_TREE;
          energy.market = MaterialMarketDestination.ENERGY;
          energy.updateBiomasses (efficiency);
          energy.updateMineralMasses ();
          energy.addProcessInHistory (this);
          
        //energy costs are entirely endorsed by ENERGY
          energy.machineWorkTime = buckingTime_h;
          energy.humanWorkTime = humanProductiveWorkTime;
          energy.fuelConsumption = fuelConsumption;
          energy.oilConsumption = oilConsumption;
          energy.lcConsumption = lcConsumption;
          energy.logisticsConsumption = logisticsConsumption;
          energy.processConsumption = processConsumption;
          energy.chainConsumption += processConsumption;
          
          outputs.add (energy);
      
        } 
        
        if (smallWoodMarketDestination.equals (MaterialMarketDestination.ND)){
        
        // Only >7 compartments are destined to energy
        // <=> <7 compartments and leaves are reduced to 0
          Resource energy = input.copy ();
          energy.processName = name ;
          energy.wetBiomassBr0_4 = 0;
          energy.wetBiomassBr4_7 = 0;
          energy.wetBiomassStem0_7 = 0;
          energy.wetBiomassLeaves = 0;
          energy.status = ResourceStatus.FALLEN_TREE;
          energy.market = MaterialMarketDestination.ENERGY;
          energy.updateBiomasses (efficiency);
          energy.updateMineralMasses ();
          energy.addProcessInHistory (this);
          
        //energy costs are entirely endorsed by ENERGY
          energy.machineWorkTime = buckingTime_h;
          energy.humanWorkTime = humanProductiveWorkTime;
          energy.fuelConsumption = fuelConsumption;
          energy.oilConsumption = oilConsumption;
          energy.lcConsumption = lcConsumption;
          energy.logisticsConsumption = logisticsConsumption;
          energy.processConsumption = processConsumption;
          energy.chainConsumption += processConsumption;
          
          outputs.add (energy);
      
        }
        
      }

      if (branchesMarketDestination.equals (MaterialMarketDestination.ND)){
      
      // Only bole is destined to energy
      // <=> <7 compartments, leaves and Branch>7 are reduced to 0
        Resource energy = input.copy ();
        energy.processName = name ;
        energy.wetBiomassLeaves = 0;
        energy.wetBiomassBr0_4 = 0;
        energy.wetBiomassBr4_7 = 0;
        energy.wetBiomassStem0_7 = 0;
        energy.wetBiomassStem7_more_top = 0;
        energy.wetBiomassBr7_more = 0;
        energy.status = ResourceStatus.FALLEN_TREE;
        energy.market = MaterialMarketDestination.ENERGY;
        energy.updateBiomasses (efficiency);
        energy.updateMineralMasses ();
        energy.addProcessInHistory (this);
        
      //energy costs are entirely endorsed by ENERGY
        energy.machineWorkTime = buckingTime_h;
        energy.humanWorkTime = humanProductiveWorkTime;
        energy.fuelConsumption = fuelConsumption;
        energy.oilConsumption = oilConsumption;
        energy.lcConsumption = lcConsumption;
        energy.logisticsConsumption = logisticsConsumption;
        energy.processConsumption = processConsumption;
        energy.chainConsumption += processConsumption;
        
        outputs.add (energy);
        
      }
      
    }
    
 }

	public String toString () {
		return "BuckingProcessBis" 
        + "name :" + name 
        + " buckingPerf:" + buckingPerf 
        + " efficiency:" + efficiency
				+ " enginePower:" + enginePower
        + " workLoad:" + workLoad
        + " machineWheight:" + machineWheight
        + " machineLifetime:" + machineLifetime
        + " stemMarketDestination:" + stemMarketDestination
        + " branchesMarketDestination:" + branchesMarketDestination
        + " smallWoodMarketDestination:" + smallWoodMarketDestination
				+ " machineToHumanTimeRatio:" + machineToHumanTimeRatio
				+ " machineCarrierNeeded:" + machineCarrierNeeded
				+ " QGPlotDistance:" + QGPlotDistance;
	}

}