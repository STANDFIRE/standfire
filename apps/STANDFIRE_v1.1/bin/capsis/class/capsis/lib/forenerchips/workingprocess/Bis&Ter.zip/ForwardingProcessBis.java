package capsis.lib.forenerchips.workingprocess;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.lib.forenerchips.Resource;
import capsis.lib.forenerchips.ResourceSite;
import capsis.lib.forenerchips.ResourceStatus;
import capsis.lib.forenerchips.WorkingProcess;

/**
 * A forwarding working process (débardeur, porteur)
 * 
 * @author N. Bilot - February 2013
 */
public class ForwardingProcessBis extends WorkingProcess {

  private String name;
	private double efficiency; // ratio
  private double forwardingPerf; // t/h
	private double enginePower; // kW
  private double workLoad; // ratio
  private double machineWheight; // t
  private double machineLifetime; // h
  private double machineToHumanTimeRatio; // e.g. 1.5
	private boolean machineCarrierNeeded; // km
	private double QGPlotDistance; // km



  
	/**
	 * Constructor.
	 */
	public ForwardingProcessBis (String name, double efficiency, double forwardingPerf, double enginePower, double workLoad, double machineWheight, double machineLifetime, double machineToHumanTimeRatio, boolean machineCarrierNeeded, double QGPlotDistance) throws Exception {
		super ("ForwardingProcessBis");

		// Check throws an exception if the condition is false
		check ("efficiency", efficiency >= 0);
    check ("efficiency", efficiency <= 1);
    check ("forwardingPerf", forwardingPerf >= 0);
    check ("enginePower", enginePower >= 0);
    check ("workLoad_Handling", workLoad >= 0);
    check ("workLoad_Handling", workLoad <= 1);
    check ("machineWheight", machineWheight >= 0);
    check ("machineLifetime", machineLifetime >= 0);
		check ("machineToHumanTimeRatio", machineToHumanTimeRatio >= 0);
		check ("QGPlotDistance", QGPlotDistance >= 0);

		this.name = name;
		this.efficiency = efficiency;
		this.forwardingPerf = forwardingPerf;
		this.enginePower = enginePower;
		this.workLoad = workLoad;
    this.machineWheight = machineWheight;
    this.machineLifetime = machineLifetime;
		this.machineToHumanTimeRatio = machineToHumanTimeRatio;
		this.machineCarrierNeeded = machineCarrierNeeded;
		this.QGPlotDistance = QGPlotDistance;

		// What resource can be processed
		addCompatibleStatusOrSite (ResourceStatus.FALLEN_TREE);
		addCompatibleStatusOrSite (ResourceStatus.LOG);
		addCompatibleStatusOrSite (ResourceStatus.RESIDUAL);
		addCompatibleStatusOrSite (ResourceStatus.BUNDLE);
		addCompatibleStatusOrSite (ResourceStatus.BRANCH);
		addCompatibleStatusOrSite (ResourceSite.PLOT);

	}

	/**
	 * Creates an instance with all parameters in a single String, for scenarios in txt files.
	 */
	static public ForwardingProcessBis getInstance (String name, String parameters) throws Exception {
		StringTokenizer st = new StringTokenizer (parameters, " ");
		
    String wpName = name;
		double efficiency = doubleValue (st.nextToken ());
		double forwardingPerf = doubleValue (st.nextToken ());
		double enginePower = doubleValue (st.nextToken ());
		double workLoad = doubleValue (st.nextToken ());
    double machineWheight = doubleValue (st.nextToken ());
    double machineLifetime = doubleValue (st.nextToken ());
		double machineToHumanTimeRatio = doubleValue (st.nextToken ());
		boolean machineCarrierNeeded = booleanValue (st.nextToken ());
		double QGPlotDistance = doubleValue (st.nextToken ());
		
		return new ForwardingProcessBis (name, efficiency, forwardingPerf, enginePower, workLoad, machineWheight, machineLifetime, machineToHumanTimeRatio, machineCarrierNeeded, QGPlotDistance);
	}

	/**
	 * Run the forwarding process
	 */
	@Override
	public void run () throws Exception {
		checkInputCompatibility ();

		// Outputs 1 resource: same status, site: ROADSIDE
		Resource output = input.copy ();
    output.processName = name ;

		output.site = ResourceSite.ROADSIDE;

		// Efficiency taken into account before treatment because only the actually forwarded biomass is considered in the process
    output.updateBiomasses (efficiency);

    // Time
    double forwardingTime_h = output.wetBiomass / forwardingPerf ;
		
		// Consumptions
		// 1. fuelConsumption
      double engineEfficiency = 0.35;
    
      double hourlyConsumption = (enginePower * workLoad) / engineEfficiency;
      double fuelConsumption = forwardingTime_h * hourlyConsumption;
	
    // 2. Oil consumption
      double oilCoefficient = 0.033;
      double oilConsumption = fuelConsumption * oilCoefficient;
      
    // 3. Life Cycle consumption equivalent
      double lcConsumption_pert = 16556; // kWh/t
      double lcConsumption_perh = machineWheight * lcConsumption_pert / machineLifetime;
      double lcConsumption = lcConsumption_perh * forwardingTime_h;
      
    // 4. Logistics consumption
      // a. operatorTravelConsumption
      double humanProductiveWorkTime = forwardingTime_h * machineToHumanTimeRatio;
      int humanProductiveWorkTime_day = (int) Math.ceil (humanProductiveWorkTime / WORKING_DAY_DURATION);
      double operatorTravelConsumption = QGPlotDistance * 2d * MEAN_CAR_CONSUMPTION * humanProductiveWorkTime_day; // kWh

      //  b. machineTravelConsumption
		double machineTravelConsumption = machineCarrierNeeded ? QGPlotDistance * 2d * MEAN_CARRIER_CONSUMPTION : 0d; // kWh

    double logisticsConsumption = operatorTravelConsumption + machineTravelConsumption;
    
    // PROCESS CONSUMPTION
    double processConsumption = fuelConsumption + oilConsumption + lcConsumption + logisticsConsumption;
    
		// Update the output resource
		output.machineWorkTime = forwardingTime_h;
    output.humanWorkTime = humanProductiveWorkTime;
    output.fuelConsumption = fuelConsumption;
    output.oilConsumption = oilConsumption;
    output.lcConsumption = lcConsumption;
    output.logisticsConsumption = logisticsConsumption;
    output.processConsumption = processConsumption;
    output.chainConsumption += processConsumption;
		output.updateMineralMasses ();
		output.addProcessInHistory (this);

		outputs.add (output);

	}

	public String toString () {
		return "ForwardingProcessBis" 
        + "name :" + name 
        + " efficiency:" + efficiency 
				+ " forwardingPerf:" + forwardingPerf
				+ " enginePower:" + enginePower
        + " workLoad:" + workLoad
        + " machineWheight:" + machineWheight
        + " machineLifetime:" + machineLifetime
				+ " machineToHumanTimeRatio:" + machineToHumanTimeRatio
				+ " machineCarrierNeeded:" + machineCarrierNeeded
				+ " QGPlotDistance:" + QGPlotDistance;
	}

}
