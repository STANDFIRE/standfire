
package capsis.lib.forenerchips.workingprocess;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.lib.forenerchips.Resource;
import capsis.lib.forenerchips.ResourceSite;
import capsis.lib.forenerchips.ResourceStatus;
import capsis.lib.forenerchips.WorkingProcess;

/**
 * A chipping working process (broyeuse)
 * 
 * @author N. Bilot - April 2013
 */
public class ChippingProcessBis extends WorkingProcess {

  private String name;
	private double chippingPerf; // t/h
  private double efficiency; // ratio
  private double enginePower; // kW
  private double workLoad; // ratio
  private double machineWheight; // t
  private double machineLifetime; // h
	private double machineToHumanTimeRatio; // e.g. 1.5
	private boolean machineCarrierNeeded; // km
	private double QGPlotDistance; // km

	/**
	 * Constructor
	 */
	public ChippingProcessBis (String name, double chippingPerf, double efficiency, double enginePower, double workLoad, double machineWheight, double machineLifetime, double machineToHumanTimeRatio, boolean machineCarrierNeeded, double QGPlotDistance) throws Exception {
		super ("ChippingProcessBis");

		// Check throws an exception if the condition is false
		check ("chippingPerf", chippingPerf >= 0);
    check ("efficiency", efficiency >= 0);
    check ("enginePower", enginePower >= 0);
    check ("workLoad", workLoad >= 0);
    check ("workLoad", workLoad <= 1);
    check ("machineWheight", machineWheight >= 0);
    check ("machineLifetime", machineLifetime >= 0);
		check ("machineToHumanTimeRatio", machineToHumanTimeRatio >= 0);
		check ("QGPlotDistance", QGPlotDistance >= 0);

		this.name = name;
		this.chippingPerf = chippingPerf;
    this.efficiency = efficiency;
    this.enginePower = enginePower;
    this.workLoad = workLoad;
    this.machineWheight = machineWheight;
    this.machineLifetime = machineLifetime;		
		this.machineToHumanTimeRatio = machineToHumanTimeRatio;
		this.machineCarrierNeeded = machineCarrierNeeded;
		this.QGPlotDistance = QGPlotDistance;
		
		// What resource can be processed
		addCompatibleStatusOrSite (ResourceStatus.FALLEN_TREE);
		addCompatibleStatusOrSite (ResourceStatus.BRANCH);
		addCompatibleStatusOrSite (ResourceStatus.RESIDUAL);
		addCompatibleStatusOrSite (ResourceStatus.LOG);
		addCompatibleStatusOrSite (ResourceStatus.BUNDLE);
		addCompatibleStatusOrSite (ResourceSite.PLOT);
		addCompatibleStatusOrSite (ResourceSite.ROADSIDE);
		addCompatibleStatusOrSite (ResourceSite.PLATFORM);
		addCompatibleStatusOrSite (ResourceSite.HEATING_PLANT);

	}

	/**
	 * Creates an instance with all parameters in a single String, for scenarios in txt files.
	 */
	static public ChippingProcessBis getInstance (String name, String parameters) throws Exception {
		StringTokenizer st = new StringTokenizer (parameters, " ");

    String wpName = name;
		double chippingPerf = doubleValue (st.nextToken ());
    double efficiency = doubleValue (st.nextToken ());
    double enginePower = doubleValue (st.nextToken ());
    double workLoad = doubleValue (st.nextToken ());
    double machineWheight = doubleValue (st.nextToken ());
    double machineLifetime = doubleValue (st.nextToken ());
		double machineToHumanTimeRatio = doubleValue (st.nextToken ());
		boolean machineCarrierNeeded = booleanValue (st.nextToken ());
		double QGPlotDistance = doubleValue (st.nextToken ());
		
		return new ChippingProcessBis (name, chippingPerf, efficiency, enginePower, workLoad, machineWheight, machineLifetime, machineToHumanTimeRatio, machineCarrierNeeded,
				QGPlotDistance);
	}

	/**
	 * Run the felling process
	 */
	@Override
	public void run () throws Exception {
		checkInputCompatibility ();

		// Outputs 1 resource: status CHIP
		Resource output = input.copy ();
    output.processName = name ;

		output.status = ResourceStatus.CHIP;

		// Consumptions
		// 1. Fuel consumption
    double engineEfficiency = 0.35;
		double chippingTime_h = input.wetBiomass / chippingPerf; 
		double hourlyConsumption = (enginePower * workLoad) / engineEfficiency ;
    double fuelConsumption = hourlyConsumption * chippingTime_h;

    // 2. Oil consumption
    double oilCoefficient = 0.02;
    double oilConsumption = fuelConsumption * oilCoefficient;
    
    // 3. Life Cycle consumption equivalent
    double lcConsumption_pert = 16556;
    double lcConsumption_perh = machineWheight * lcConsumption_pert / machineLifetime;
    double lcConsumption = lcConsumption_perh * chippingTime_h;
        
    // 4. Logistics consumption
      //  a. operatorTravelConsumption
      double humanProductiveWorkTime = chippingTime_h * machineToHumanTimeRatio;
      int humanProductiveWorkTime_day = (int) Math.ceil (humanProductiveWorkTime / WORKING_DAY_DURATION);
      double operatorTravelConsumption = QGPlotDistance * 2d * MEAN_CAR_CONSUMPTION * humanProductiveWorkTime_day; // kWh

      //  b. machineTravelConsumption
      double machineTravelConsumption = machineCarrierNeeded ? QGPlotDistance * 2d * MEAN_CARRIER_CONSUMPTION : 0d; // kWh

    double logisticsConsumption = operatorTravelConsumption + machineTravelConsumption;
    
    // PROCESS CONSUMPTION
		double processConsumption = fuelConsumption + oilConsumption + lcConsumption + logisticsConsumption;

		// Update the output resource
    output.machineWorkTime = chippingTime_h;
    output.humanWorkTime = humanProductiveWorkTime;
    output.fuelConsumption = fuelConsumption;
    output.oilConsumption = oilConsumption;
    output.lcConsumption = lcConsumption;
    output.logisticsConsumption = logisticsConsumption;
    output.processConsumption = processConsumption;
    output.chainConsumption += processConsumption;
    output.updateBiomasses (efficiency);
		output.updateMineralMasses ();

		output.addProcessInHistory (this);

		outputs.add (output);

	}

	public String toString () {
		return "ChippingProcessBis" 
        + "name :" + name 
        + " chippingPerf:" + chippingPerf 
        + " efficiency:" + efficiency
        + " enginePower:" + enginePower
        + " workLoad:" + workLoad
        + " machineWheight:" + machineWheight
        + " machineLifetime:" + machineLifetime
				+ " machineToHumanTimeRatio:" + machineToHumanTimeRatio 
        + " machineCarrierNeeded:" + machineCarrierNeeded 
        + " QGPlotDistance:" + QGPlotDistance;
	}

}
