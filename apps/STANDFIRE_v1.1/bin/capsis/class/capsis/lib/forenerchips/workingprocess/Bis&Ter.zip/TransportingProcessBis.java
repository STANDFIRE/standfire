package capsis.lib.forenerchips.workingprocess;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.lib.forenerchips.Resource;
import capsis.lib.forenerchips.ResourceSite;
import capsis.lib.forenerchips.ResourceStatus;
import capsis.lib.forenerchips.WorkingProcess;

/**
 * A transporting working process (transport)
 * 
 * @author N. Bilot - February 2013
 */
public class TransportingProcessBis extends WorkingProcess {

  private String name;
	private double volumeCapacity; // m3
	private double weightCapacity; // t
  private double enginPower; // kW
	private double workloadFull; // ratio
	private double workloadEmpty; // ratio
  private double unladenWheight; // t
  private double truckLifeDistance; // km
	private double travelDistance; // km
  private double averageSpeed; // km
	private String resourceDestination; // ResourceSite.PLATFORM or ResourceSite.HEATING_PLANT only


	/**
	 * Constructor.
	 */
	public TransportingProcessBis (String name, double volumeCapacity, double weightCapacity, double enginPower, double workloadFull, double workloadEmpty, double unladenWheight, double truckLifeDistance, double travelDistance, double averageSpeed, String resourceDestination) throws Exception {
		super ("TransportingProcessBis");

		// Check throws an exception if the condition is false
		check ("volumeCapacity", volumeCapacity >= 0);
		check ("weightCapacity", weightCapacity >= 0);
    check ("enginPower", enginPower >= 0);
		check ("workloadFull", workloadFull >= 0);
		check ("workloadEmpty", workloadEmpty >= 0);
    check ("unladenWheight", unladenWheight >= 0);
    check ("truckLifeDistance", truckLifeDistance >= 0);
		check ("workloadEmpty / Full", workloadEmpty <= workloadFull);
		check ("travelDistance", travelDistance >= 0);
    check ("averageSpeed", averageSpeed >= 0);    
		check ("resourceDestination", resourceDestination.equals (ResourceSite.PLATFORM)
				|| resourceDestination.equals (ResourceSite.HEATING_PLANT));

		this.name = name;
    this.volumeCapacity = volumeCapacity;
		this.weightCapacity = weightCapacity;
		this.enginPower = enginPower;
    this.workloadFull = workloadFull;
		this.workloadEmpty = workloadEmpty;
    this.unladenWheight = unladenWheight;
    this.truckLifeDistance = truckLifeDistance;
		this.travelDistance = travelDistance;
    this.averageSpeed = averageSpeed;
		this.resourceDestination = resourceDestination;

		// What resource can be processed
		addCompatibleStatusOrSite (ResourceStatus.FALLEN_TREE);
		addCompatibleStatusOrSite (ResourceStatus.LOG);
		addCompatibleStatusOrSite (ResourceStatus.RESIDUAL);
		addCompatibleStatusOrSite (ResourceStatus.BUNDLE);
		addCompatibleStatusOrSite (ResourceStatus.BRANCH);
		addCompatibleStatusOrSite (ResourceStatus.CHIP);
		addCompatibleStatusOrSite (ResourceSite.ROADSIDE);
		addCompatibleStatusOrSite (ResourceSite.PLATFORM);

	}

	/**
	 * Creates an instance with all parameters in a single String, for scenarios in txt files.
	 */
	static public TransportingProcessBis getInstance (String name, String parameters) throws Exception {
		StringTokenizer st = new StringTokenizer (parameters, " ");
		
    String wpName = name;
    double volumeCapacity = doubleValue (st.nextToken ());
		double weightCapacity = doubleValue (st.nextToken ());
    double enginPower = doubleValue (st.nextToken ());
		double workloadFull = doubleValue (st.nextToken ());
		double workloadEmpty = doubleValue (st.nextToken ());
    double unladenWheight = doubleValue (st.nextToken ());
    double truckLifeDistance = doubleValue (st.nextToken ());
		double travelDistance = doubleValue (st.nextToken ());
    double averageSpeed = doubleValue (st.nextToken ());
		String resourceDestination = st.nextToken ();
		if (resourceDestination.equals ("PLATFORM")) 
			resourceDestination = ResourceSite.PLATFORM;
		else if (resourceDestination.equals ("HEATING_PLANT")) 
			resourceDestination = ResourceSite.HEATING_PLANT;
		else 
			throw new Exception ("TransportingProcessBis: wrong value for resourceDestination: "+resourceDestination+", must be PLATFORM or HEATING_PLANT");
		
		return new TransportingProcessBis (name, volumeCapacity, weightCapacity, enginPower, workloadFull,workloadEmpty, unladenWheight, truckLifeDistance, travelDistance, averageSpeed, resourceDestination);
	}

	/**
	 * Run the process
	 */
	@Override
	public void run () throws Exception {
		checkInputCompatibility ();

		// Outputs 1 resource: same status, site: ROADSIDE
		Resource output = input.copy ();

    output.processName = name ;
		output.site = resourceDestination;

		// Efficiency
		double efficiency = 1;

		double bulkDensity = 0;
		if (input.status.equals (ResourceStatus.FALLEN_TREE)) {
			bulkDensity = 0.4;
		} else if (input.status.equals (ResourceStatus.LOG)) {
			bulkDensity = 0.8;
		} else if (input.status.equals (ResourceStatus.RESIDUAL)) {
			bulkDensity = 0.3;
		} else if (input.status.equals (ResourceStatus.BUNDLE)) {
			bulkDensity = 0.8;
		} else if (input.status.equals (ResourceStatus.BRANCH)) {
			bulkDensity = 0.4;
		} else if (input.status.equals (ResourceStatus.CHIP)) {
			bulkDensity = 0.3;
		}

		double oneTripBiomass = 0;
		if (bulkDensity > weightCapacity / volumeCapacity) {
			oneTripBiomass = weightCapacity;
		} else {
			oneTripBiomass = volumeCapacity * bulkDensity;
		}
		int numberOfJourneys = (int) Math.ceil (input.wetBiomass / oneTripBiomass);

		// Consumptions
    // 1. Fuel consumption
    double engineEfficiency = 0.35; // ratio of efficiency of transformation of fuel energy in mecanical work.
        
    // workTimes : human = machine (not considering loading time during)
    double transportTime_h = (numberOfJourneys * 2 * travelDistance) / averageSpeed  ;
    
    // energy consumption when the truck is empty, kW
    double fuelConsumptionEmpty_kW = workloadEmpty * enginPower / engineEfficiency ; 
    
    // energy consumption when the truck is fully loaded, kWh/km
    double fuelConsumptionFull_kW = workloadFull * enginPower / engineEfficiency ; 
    
		double fuelConsumption  = fuelConsumptionEmpty_kW * transportTime_h / 2 + fuelConsumptionFull_kW * transportTime_h / 2;
    
    // 2. Oil consumption
    double oilConsumption = 0.0008 * fuelConsumption;
    
    // 3. Life cycle consumption equivalent
    double lcConsumption_pert = 16556;
    double lcConsumption_perkm = unladenWheight * lcConsumption_pert / truckLifeDistance;
    double lcConsumption = lcConsumption_perkm * travelDistance;
    
    // 4. Logistics' consumption
    // In this case, the operator comes to the site with the machine, so there is no logistics comsumption
    double logisticsConsumption = 0;
    
    // 5. TOTAL consumption for the process
    double processConsumption = fuelConsumption + oilConsumption + lcConsumption + logisticsConsumption;

		
    

		// Update the output resource
		output.machineWorkTime = transportTime_h;
    output.humanWorkTime = transportTime_h;
    output.fuelConsumption = fuelConsumption;
    output.oilConsumption = oilConsumption;
    output.lcConsumption = lcConsumption;
    output.logisticsConsumption = logisticsConsumption;
    output.processConsumption = processConsumption;
    output.chainConsumption += processConsumption;
		output.updateBiomasses (efficiency);
		output.updateMineralMasses ();
		output.addProcessInHistory (this);

		outputs.add (output);

	}

	public String toString () {
		return "TransportingProcessBis" 
        + "name :" + name 
        + " volumeCapacity:" + volumeCapacity 
				+ " weightCapacity:" + weightCapacity
				+ " enginPower:" + enginPower
				+ " workloadFull:" + workloadFull
        + " workloadEmpty:" + workloadEmpty
        + " unladenWheight:" + unladenWheight
        + " truckLifeDistance:" + truckLifeDistance
				+ " travelDistance:" + travelDistance
        + " averageSpeed:" + averageSpeed
				+ " resourceDestination:" + resourceDestination;
	}

}
