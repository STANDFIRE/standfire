package capsis.lib.forenerchips.workingprocess;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.lib.forenerchips.Resource;
import capsis.lib.forenerchips.ResourceSite;
import capsis.lib.forenerchips.ResourceStatus;
import capsis.lib.forenerchips.WorkingProcess;

/**
 * A shaping working process (faconneuse)
 * 
 * @author N. Bilot - February 2013
 */
public class ShapingProcessBis extends WorkingProcess {

  private String name;
	private double shapingPerf; // t/h
  private double efficiency; // kW
  private double enginePower; // kW
  private double workLoad; // ratio
  private double machineWheight; // t
  private double machineLifetime; // h
  private boolean keepStem; // boolean
  private boolean keepBranchesLargeCompartments; // boolean
  private boolean keepSmall; // boolean
	private double machineToHumanTimeRatio; // e.g. 1.5
	private boolean machineCarrierNeeded; // km
	private double QGPlotDistance; // km


	/**
	 * Constructor.
	 */
   public ShapingProcessBis (String name, double shapingPerf, double efficiency, double enginePower, double workLoad, double machineWheight, double machineLifetime, boolean keepStem, boolean keepBranchesLargeCompartments, boolean keepSmall, double machineToHumanTimeRatio, boolean machineCarrierNeeded, double QGPlotDistance) throws Exception {
		super ("ShapingProcessBis");

		// Check throws an exception if the condition is false
		check ("shapingPerf", shapingPerf >= 0);
    check ("efficiency", efficiency >= 0);
		check ("enginePower", enginePower >= 0);
    check ("workLoad", workLoad >= 0);
    check ("workLoad", workLoad <= 1);
    check ("machineWheight", machineWheight >= 0);
    check ("machineLifetime", machineLifetime >= 0);
		check ("machineToHumanTimeRatio", machineToHumanTimeRatio >= 0);
		check ("QGPlotDistance", QGPlotDistance >= 0);

		this.name = name;
		this.shapingPerf = shapingPerf;
    this.efficiency = efficiency;
    this.enginePower = enginePower;
		this.workLoad = workLoad;
    this.machineWheight = machineWheight;
    this.machineLifetime = machineLifetime;
    this.keepStem = keepStem;
    this.keepBranchesLargeCompartments = keepBranchesLargeCompartments;
    this.keepSmall = keepSmall;
		this.machineToHumanTimeRatio = machineToHumanTimeRatio;
		this.machineCarrierNeeded = machineCarrierNeeded;
		this.QGPlotDistance = QGPlotDistance;

		// What resource can be processed
		addCompatibleStatusOrSite (ResourceStatus.FALLEN_TREE);
    addCompatibleStatusOrSite (ResourceStatus.BRANCH);
		addCompatibleStatusOrSite (ResourceSite.PLOT);
		addCompatibleStatusOrSite (ResourceSite.ROADSIDE);

	}

	/**
	 * Creates an instance with all parameters in a single String, for scenarios in txt files.
	 */
	static public ShapingProcessBis getInstance (String name, String parameters) throws Exception {
		StringTokenizer st = new StringTokenizer (parameters, " ");
		
    String wpName = name;
		double shapingPerf = doubleValue (st.nextToken ());
    double efficiency = doubleValue (st.nextToken ());
		double enginePower = doubleValue (st.nextToken ());
    double workLoad = doubleValue (st.nextToken ());
    double machineWheight = doubleValue (st.nextToken ());
    double machineLifetime = doubleValue (st.nextToken ());
    boolean keepStem = booleanValue (st.nextToken ());
		boolean keepBranchesLargeCompartments = booleanValue (st.nextToken ());
    boolean keepSmall = booleanValue (st.nextToken ());
		double machineToHumanTimeRatio = doubleValue (st.nextToken ());
		boolean machineCarrierNeeded = booleanValue (st.nextToken ());
		double QGPlotDistance = doubleValue (st.nextToken ());
		
		return new ShapingProcessBis (name, shapingPerf, efficiency, enginePower, workLoad, machineWheight, machineLifetime, keepStem, keepBranchesLargeCompartments, keepSmall, machineToHumanTimeRatio, machineCarrierNeeded, QGPlotDistance);
	}

	/**
	 * Run the shaping process
	 */
	@Override
	public void run () throws Exception {
		checkInputCompatibility ();

		
    // Consumptions
		// 1. fuelConsumption
      double engineEfficiency = 0.35;
		
      double shapingTime_h = input.wetBiomass / shapingPerf;
      double hourlyConsumption = enginePower * workLoad / engineEfficiency ;
      double fuelConsumption = hourlyConsumption * shapingTime_h;
    
    // 2. Oil consumption
    double oilCoefficient = 0d;
    if(machineCarrierNeeded){
      oilCoefficient = 0.058;
    } else {
      oilCoefficient = 0.322;
    }
      double oilConsumption = fuelConsumption * oilCoefficient;
    
    // 3. Life Cycle consumption equivalent
      double lcConsumption_pert = 16556;
      double lcConsumption_perh = machineWheight * lcConsumption_pert / machineLifetime;
      double lcConsumption = lcConsumption_perh * shapingTime_h;

    // 4. Logistics consumption
      // a. operatorTravelConsumption
      double humanProductiveWorkTime = shapingTime_h * machineToHumanTimeRatio;
      int humanProductiveWorkTime_day = (int) Math.ceil (humanProductiveWorkTime / WORKING_DAY_DURATION);
      double operatorTravelConsumption = QGPlotDistance * 2d * MEAN_CAR_CONSUMPTION * humanProductiveWorkTime_day; // kWh

      //  b. machineTravelConsumption
      double machineTravelConsumption = machineCarrierNeeded ? QGPlotDistance * 2d * MEAN_CARRIER_CONSUMPTION : 0d; // kWh

    double logisticsConsumption = operatorTravelConsumption + machineTravelConsumption;

    // PROCESS CONSUMPTION
    double processConsumption = fuelConsumption + oilConsumption + lcConsumption + logisticsConsumption;

		// Update the output resource
    Resource EnergyWood = input.copy ();
    EnergyWood.processName = name ;
		
    // Update quantities
		if (!keepStem) {
      // Bole compartment is removed
      EnergyWood.wetBiomassStem7_more_bole = 0;
    }

    if(!keepBranchesLargeCompartments) {
      // Branches large compartment and stem top are removed
      EnergyWood.wetBiomassStem7_more_top = 0;
      EnergyWood.wetBiomassBr7_more = 0;
    }
      
    if(!keepSmall) {
      // Branches large compartments are removed
      EnergyWood.wetBiomassBr0_4 = 0;
      EnergyWood.wetBiomassBr4_7 = 0;
      EnergyWood.wetBiomassStem0_7 = 0;
      EnergyWood.wetBiomassLeaves = 0;
    }
      
    // Update Status
    if (!keepStem){
      if(!keepBranchesLargeCompartments){
        EnergyWood.status = ResourceStatus.RESIDUAL;
      } else if (keepSmall) {
        EnergyWood.status = ResourceStatus.BRANCH;
      } else if (!keepSmall){
        EnergyWood.status = ResourceStatus.LOG;
      }
    } else {
      if(!keepBranchesLargeCompartments){
        EnergyWood.status = ResourceStatus.LOG;
      } else if (keepSmall) {
        EnergyWood.status = ResourceStatus.FALLEN_TREE;
      } else if (!keepSmall){
        EnergyWood.status = ResourceStatus.LOG;
      }
    }
      
      EnergyWood.updateBiomasses (efficiency);
      EnergyWood.updateMineralMasses ();
      EnergyWood.addProcessInHistory (this);
      
      EnergyWood.machineWorkTime = shapingTime_h;
      EnergyWood.humanWorkTime = humanProductiveWorkTime;
      EnergyWood.fuelConsumption = fuelConsumption;
      EnergyWood.oilConsumption = oilConsumption;
      EnergyWood.lcConsumption = lcConsumption;
      EnergyWood.logisticsConsumption = logisticsConsumption;
      EnergyWood.processConsumption = processConsumption;
      EnergyWood.chainConsumption += processConsumption;
      
      outputs.add (EnergyWood);
  }

	public String toString () {
		return "ShapingProcessBis" 
        + "name :" + name 
        + " shapingPerf:" + shapingPerf 
        + " efficiency:" + efficiency
				+ " enginePower:" + enginePower
        + " workLoad:" + workLoad
        + " machineWheight:" + machineWheight
        + " machineLifetime:" + machineLifetime
        + " keepStem:" + keepStem
        + " keepBranchesLargeCompartments:" + keepBranchesLargeCompartments
        + " keepSmall:" + keepSmall
				+ " machineToHumanTimeRatio:" + machineToHumanTimeRatio
				+ " machineCarrierNeeded:" + machineCarrierNeeded
				+ " QGPlotDistance:" + QGPlotDistance;
	}

}